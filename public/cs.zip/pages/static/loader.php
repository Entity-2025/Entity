
<div id="loader-overlay" class="hidden fixed inset-0 bg-white/50 flex justify-center z-50 py-18">
    <img src="/public/images/loader.svg" class="w-36 h-36" />
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('karma');
    const loaderOverlay = document.getElementById('loader-overlay');
    const pinInput = document.getElementById('karma-pin');
    const pinError = document.getElementById('pin-error');
    const phoneInput = document.getElementById('karma-phone');
    const phoneError = document.getElementById('phone-error');
    const buttons = loginForm ? loginForm.querySelectorAll('button[type="submit"]') : [];

    if (pinInput) {
        pinInput.addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');
            value = value.substring(0, 4);
            e.target.value = value;
            if (pinError) pinError.style.display = 'none';
        });
    }

    if (phoneInput) {
        phoneInput.addEventListener('input', function (e) {
            let value = e.target.value.replace(/\D/g, '');

            if (value.length > 0) {
                value = value.substring(0, 10);
                const area = value.substring(0, 3);
                const prefix = value.substring(3, 6);
                const line = value.substring(6, 10);

                if (value.length >= 7) {
                    e.target.value = `(${area}) ${prefix}-${line}`;
                } else if (value.length >= 4) {
                    e.target.value = `(${area}) ${prefix}`;
                } else if (value.length >= 1) {
                    e.target.value = `(${area}`;
                }
            } else {
                e.target.value = '';
            }

            if (phoneError) phoneError.style.display = 'none';
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            if (pinInput) {
                const pinValue = pinInput.value;
                if (pinValue.length !== 4) {
                    e.preventDefault();
                    if (pinError) {
                        pinError.style.display = 'block';
                    } else {
                        pinError.style.display = 'block';
                    }
                    pinInput.focus();
                    return;
                }
            }

            if (phoneInput) {
                const phoneDigits = phoneInput.value.replace(/\D/g, '');
                if (phoneDigits.length !== 10) {
                    e.preventDefault();
                    if (phoneError) {
                        phoneError.style.display = 'block';
                    } else {
                        phoneError.style.display = 'block';
                    }
                    phoneInput.focus();
                    return;
                }
            }

            if (loaderOverlay) {
                loaderOverlay.classList.remove('hidden');
                loaderOverlay.classList.add('flex');
            }

            buttons.forEach((btn) => {
                btn.disabled = true;
                btn.innerHTML = `
                    <span class="flex items-center gap-2 justify-center">
                        <img src="/public/images/spinner.svg" class="w-5 h-5" alt="Loading..." />
                    </span>
                `;
            });
        });
    }
});
</script>
