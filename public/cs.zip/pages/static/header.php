<header class="flex flex-col gap-[1.5px] sticky top-0 z-50 bg-white">
    <div class="bg-[#001e45] flex justify-between">
        <div class="flex gap-1 md:gap-3 items-center px-3 md:px-14 py-2">
            <img src="/public/images/MAG.svg" class="h-5" />
            <input
                type="s"
                name="s"
                placeholder="Search Site"
                required
                class="hidden md:flex mr-2 text-base md:text-xl w-full max-w-[210px] h-8 px-4 py-2 bg-[#ffffffcc] focus:outline-none text-black placeholder:text-sm lg:placeholder:text-xl"
            />
            <p class="text-white text-sm lg:text-lg hover:underline cursor-pointer">Call Us: (888) 345-5509</p>
        </div>
            <div class="flex gap-2 items-center px-3 md:px-14 py-2 font-semibold">
            <p class="text-white text-sm lg:text-lg hover:underline cursor-pointer hidden lg:flex">Español</p>
            <span class="text-white hidden lg:flex">|</span>
            <p class="text-white text-sm lg:text-lg hover:underline cursor-pointer hidden md:flex">Find Us in Stores</p>
            <p class="text-white text-sm lg:text-lg hover:underline cursor-pointer flex md:hidden">Stores</p>
        </div>
    </div>
    <div id="main-header" class="bg-[#f26631] px-3 md:px-14 flex justify-between items-end transition-all duration-300 ease-in-out">
        <div id="svg-items" class="transition-all duration-300 ease-in-out py-2 md:py-5">
            <img src="/public/images/CS.svg" id="main-logo" class="h-6 md:h-9 lg:h-14 mb-0 transition-all duration-300 ease-in-out" />
        </div>
        <div id="nav-items" class="hidden md:flex gap-5 xl:gap-8 font-bold text-sm lg:text-xl xl:text-2xl text-white items-end py-2 transition-all duration-300 ease-in-out">
            <p>HOME</p>
            <p>PLANS</p>
            <p>SHOP</p>
            <p>ABOUT US</p>
            <p>HELP</p>
            <?php if (isset($_SESSION['karma-logged'])): ?>
                <p>LOGOUT</p>
            <?php else: ?>
                <p>LOGIN</p>
            <?php endif; ?>
        </div>
        <div id="nav-items" class="flex md:hidden gap-3 font-bold text-sm lg:text-xl xl:text-2xl text-white items-end py-2 transition-all duration-300 ease-in-out">
            <img src="/public/images/person.svg" class="w-6 h-6" />
            <img src="/public/images/menu.svg" class="w-6 h-6" />
        </div>
    </div>
    <div class="bg-white"></div>
</header>
<script>
    const header = document.getElementById('main-header');
    const logoDiv = document.getElementById('svg-items');
    const logo = document.getElementById('main-logo');

    function handleScroll() {
        if (window.innerWidth > 720) {
            if (window.scrollY > 50) {
                logoDiv.style.paddingTop = '0.25rem';
                logoDiv.style.paddingBottom = '0.25rem';

                logo.style.maxHeight = '2rem';
                logo.classList.add('mb-1');
                logo.classList.remove('mb-0');
            } else {
                logoDiv.style.paddingTop = '1.25rem';
                logoDiv.style.paddingBottom = '1.25rem';

                logo.style.maxHeight = '3.5rem';
                logo.classList.add('mb-0');
                logo.classList.remove('mb-1');
            }
        } else {
            logoDiv.style.paddingTop = '0.50rem';
            logoDiv.style.paddingBottom = '0.50rem';
            logo.style.maxHeight = '3.5rem';
            logo.classList.add('mb-0');
            logo.classList.remove('mb-1');
        }
    }

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleScroll);
</script>