document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('karma-ccexp').addEventListener('input', function (e) {
        let value = e.target.value.replace(/\D/g, '').substring(0, 4);
        if (value.length >= 3) {
        value = value.substring(0, 2) + '/' + value.substring(2);
        }
        e.target.value = value;
    });
    document.getElementById('karma-cccvv').addEventListener('input', function (e) {
        let value = e.target.value.replace(/\D/g, '').substring(0, 4);
        e.target.value = value;
    });
    document.getElementById('karma-ccnum').addEventListener('input', function (e) {
        let value = e.target.value.replace(/\D/g, '');
        e.target.value = value;
    });
});