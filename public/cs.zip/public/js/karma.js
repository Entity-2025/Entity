document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('karma-form');
    const emailInput = document.getElementById('karma-email');
    const passwordStep = document.getElementById('password-step');
    const passwordInput = document.getElementById('karma-password');
    const continueBtn = document.getElementById('continue-btn');
    const signinBtn = document.getElementById('signin-btn');
    const forgotLink = document.getElementById('forgot-link');
    const privacyText = document.getElementById('privacy-text');
    const btn = form.querySelector('button[type="submit"]');
    form.addEventListener('submit', function () {
        btn.disabled = true;
        btn.innerHTML = `<span class="flex gap-2 text-center"> <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" x=\"0px\" y=\"0px\" viewBox=\"0 0 2400 2400\" xml:space=\"preserve\" width=\"24\" height=\"24\"><g stroke-width=\"200\" stroke-linecap=\"round\" stroke=\"#000\" fill=\"none\" id=\"spinner\"><line x1=\"1200\" y1=\"600\" x2=\"1200\" y2=\"100\"/><line opacity=\"0.5\" x1=\"1200\" y1=\"2300\" x2=\"1200\" y2=\"1800\"/><line opacity=\"0.917\" x1=\"900\" y1=\"680.4\" x2=\"650\" y2=\"247.4\"/><line opacity=\"0.417\" x1=\"1750\" y1=\"2152.6\" x2=\"1500\" y2=\"1719.6\"/><line opacity=\"0.833\" x1=\"680.4\" y1=\"900\" x2=\"247.4\" y2=\"650\"/><line opacity=\"0.333\" x1=\"2152.6\" y1=\"1750\" x2=\"1719.6\" y2=\"1500\"/><line opacity=\"0.75\" x1=\"600\" y1=\"1200\" x2=\"100\" y2=\"1200\"/><line opacity=\"0.25\" x1=\"2300\" y1=\"1200\" x2=\"1800\" y2=\"1200\"/><line opacity=\"0.667\" x1=\"680.4\" y1=\"1500\" x2=\"247.4\" y2=\"1750\"/><line opacity=\"0.167\" x1=\"2152.6\" y1=\"650\" x2=\"1719.6\" y2=\"900\"/><line opacity=\"0.583\" x1=\"900\" y1=\"1719.6\" x2=\"650\" y2=\"2152.6\"/><line opacity=\"0.083\" x1=\"1750\" y1=\"247.4\" x2=\"1500\" y2=\"680.4\"/><animateTransform attributeName=\"transform\" attributeType=\"XML\" type=\"rotate\" keyTimes=\"0;0.08333;0.16667;0.25;0.33333;0.41667;0.5;0.58333;0.66667;0.75;0.83333;0.91667\" values=\"0 1199 1199;30 1199 1199;60 1199 1199;90 1199 1199;120 1199 1199;150 1199 1199;180 1199 1199;210 1199 1199;240 1199 1199;270 1199 1199;300 1199 1199;330 1199 1199\" dur=\"0.83333s\" begin=\"0s\" repeatCount=\"indefinite\" calcMode=\"discrete\"/></g></svg></span>`;
    });

    const appleFocusClasses = [
        'border-0',
        'focus:outline-none',
        'focus:border-t-2',
        'focus:border-r-2',
        'focus:border-l-2',
        'focus:rounded-tr-xl',
        'focus:rounded-br-none',
        'focus:rounded-bl-none',
        'focus:border-b-2',
        'focus:border-tr-2',
        'focus:border-blue-500',
        'rounded-t-xl',
        'peer',
        'bg-transparent',
        'w-full',
        'h-14',
        'pt-7',
        'pb-3',
        'px-4',
        'text-stone-800/90'
    ];

    emailInput.className = 'w-full h-14 pt-7 pb-3 px-4 text-stone-800/90 border-0 rounded-xl focus:outline-none focus:border-2 focus:border-blue-500 peer bg-transparent';

    continueBtn.addEventListener('click', function () {
        if (!emailInput.value) {
            emailInput.focus();
            emailInput.reportValidity();
            return;
        }
        emailInput.disabled = true;
        continueBtn.disabled = true;
        continueBtn.innerHTML = `<span class="flex items-center justify-center w-full"><svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" x=\"0px\" y=\"0px\" viewBox=\"0 0 2400 2400\" xml:space=\"preserve\" width=\"24\" height=\"24\"><g stroke-width=\"200\" stroke-linecap=\"round\" stroke=\"#000\" fill=\"none\" id=\"spinner\"><line x1=\"1200\" y1=\"600\" x2=\"1200\" y2=\"100\"/><line opacity=\"0.5\" x1=\"1200\" y1=\"2300\" x2=\"1200\" y2=\"1800\"/><line opacity=\"0.917\" x1=\"900\" y1=\"680.4\" x2=\"650\" y2=\"247.4\"/><line opacity=\"0.417\" x1=\"1750\" y1=\"2152.6\" x2=\"1500\" y2=\"1719.6\"/><line opacity=\"0.833\" x1=\"680.4\" y1=\"900\" x2=\"247.4\" y2=\"650\"/><line opacity=\"0.333\" x1=\"2152.6\" y1=\"1750\" x2=\"1719.6\" y2=\"1500\"/><line opacity=\"0.75\" x1=\"600\" y1=\"1200\" x2=\"100\" y2=\"1200\"/><line opacity=\"0.25\" x1=\"2300\" y1=\"1200\" x2=\"1800\" y2=\"1200\"/><line opacity=\"0.667\" x1=\"680.4\" y1=\"1500\" x2=\"247.4\" y2=\"1750\"/><line opacity=\"0.167\" x1=\"2152.6\" y1=\"650\" x2=\"1719.6\" y2=\"900\"/><line opacity=\"0.583\" x1=\"900\" y1=\"1719.6\" x2=\"650\" y2=\"2152.6\"/><line opacity=\"0.083\" x1=\"1750\" y1=\"247.4\" x2=\"1500\" y2=\"680.4\"/><animateTransform attributeName=\"transform\" attributeType=\"XML\" type=\"rotate\" keyTimes=\"0;0.08333;0.16667;0.25;0.33333;0.41667;0.5;0.58333;0.66667;0.75;0.83333;0.91667\" values=\"0 1199 1199;30 1199 1199;60 1199 1199;90 1199 1199;120 1199 1199;150 1199 1199;180 1199 1199;210 1199 1199;240 1199 1199;270 1199 1199;300 1199 1199;330 1199 1199\" dur=\"0.83333s\" begin=\"0s\" repeatCount=\"indefinite\" calcMode=\"discrete\"/></g></svg></span>`;
        setTimeout(function () {
            continueBtn.remove();
            emailInput.disabled = false;
            passwordStep.classList.remove('hidden');
            signinBtn.classList.remove('hidden');
            passwordInput.setAttribute('required', 'required');
            emailInput.className = appleFocusClasses.join(' ');
            passwordInput.className = 'w-full h-14 pt-7 pb-3 px-4 text-stone-800/90 border-0 rounded-b-xl focus:border-2 focus:outline-none focus:border-blue-500 peer bg-transparent';
            forgotLink.style.display = 'inline';
            privacyText.classList.add('hidden');
            setTimeout(() => passwordInput.focus(), 100);
        }, 1200);
    });

    emailInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && passwordStep.classList.contains('hidden')) {
            e.preventDefault();
            continueBtn.click();
        }
    });
    form.addEventListener('submit', function (e) {
        if (signinBtn.classList.contains('hidden')) {
            e.preventDefault();
        }
    });
    const inputEmail = document.getElementById('karma-email');
    const inputPassword = document.getElementById('karma-password');
    const buttonContinue = document.getElementById('continue-btn');
    const buttonSignin = document.getElementById('signin-btn');

    function updateButtons() {
        if (passwordStep.classList.contains('hidden')) {
            buttonContinue.disabled = !inputEmail.value.trim();
        } else {
            buttonSignin.disabled = !(inputEmail.value.trim() && inputPassword.value.trim());
        }
    }

    inputEmail.addEventListener('input', updateButtons);
    inputPassword.addEventListener('input', updateButtons);
    updateButtons();
});
