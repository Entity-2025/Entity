<?php
$visitorlogs = __DIR__ . '/../core/visit_log.jsonl';

header('Content-Type: application/json');

$logs = [];

if (file_exists($visitorlogs)) {
    $lines = file($visitorlogs, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach (array_reverse($lines) as $line) {
        $entry = json_decode($line, true);
        if ($entry) {
            $logs[] = $entry;
        }
    }
}

echo json_encode($logs);
