async function fetchLogs() {
    try {
        const response = await fetch('/[KARMA]/pages/get_logs.php');
        const logs = await response.json();

        const emptyState = document.getElementById('empty-state');
        const dashboardContent = document.getElementById('dashboard-content');
        const clearBtn = document.getElementById('clear-logs-container');
        const logContainer = document.getElementById('log-container');

        if (!logs.length) {
            emptyState.classList.remove('hidden');
            dashboardContent.classList.add('hidden');
            return;
        }

        emptyState.classList.add('hidden');
        dashboardContent.classList.remove('hidden');
        clearBtn.classList.remove('hidden');

        let table = `
        <table class="min-w-full bg-white text-sm text-left text-gray-700">
            <thead class="bg-stone-700 text-white/90 uppercase text-xs font-semibold tracking-wider sticky top-0 z-10">
                <tr>
                    <th class="px-6 py-3 border-b">Jam</th>
                    <th class="px-6 py-3 border-b">IP</th>
                    <th class="px-6 py-3 border-b">ISP</th>
                    <th class="px-6 py-3 border-b">Negara</th>
                    <th class="px-6 py-3 border-b">Bendera</th>
                    <th class="px-6 py-3 border-b">Info</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">`;

        for (let log of logs) {
            table += `
                <tr class="hover:bg-stone-700 hover:text-white/90 hover:font-semibold transition text-black/90">
                    <td class="px-6 py-4">${log.JAM}</td>
                    <td class="px-6 py-4">${log.IP}</td>
                    <td class="px-6 py-4">${log.ISP}</td>
                    <td class="px-6 py-4">${log.NEGARA}</td>
                    <td class="px-6 py-4"><img src="${log.BENDERA}" alt="Flag" class="h-5 w-auto"></td>
                    <td class="px-6 py-4 font-semibold text-[#f26631]">${log.INFO}</td>
                </tr>`;
        }

        table += '</tbody></table>';
        logContainer.innerHTML = table;

    } catch (error) {
        console.error('Error fetching logs:', error);
    }
}

async function fetchSummary() {
    try {
        const response = await fetch('/[KARMA]/pages/get_log_cards.php');
        const data = await response.json();

        const container = document.getElementById('summary-container');
        container.innerHTML = '';

        for (const [label, count] of Object.entries(data)) {
            const card = document.createElement('div');
            card.className = "bg-white border-2 border-black/60 hover:text-[#f26631] hover:border-green-500 rounded-2xl shadow p-6 text-center transition duration-200";

            card.innerHTML = `
                <div class="text-sm mb-1 font-semibold">${label.charAt(0) + label.slice(1).toLowerCase()}</div>
                <div class="text-3xl font-bold text-green-500">${count}</div>
            `;

            container.appendChild(card);
        }

    } catch (error) {
        console.error('Error fetching summary:', error);
    }
}

fetchLogs();
fetchSummary();
setInterval(() => {
    fetchLogs();
    fetchSummary();
}, 5000);