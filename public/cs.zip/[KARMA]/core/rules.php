<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function random($length = 10)
{
    return substr(str_shuffle(str_repeat(
        '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', 
        ceil($length / 62)
    )), 0, $length);
}

?>