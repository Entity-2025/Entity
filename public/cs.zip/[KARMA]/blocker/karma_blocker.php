<?php
function karma_blocker() {
    $config = require __DIR__ . '/../config/config.php';
    $botFile = __DIR__ . '/bot.txt';
    require __DIR__ . '/../core/functions.php';
    if (!file_exists($botFile)) return;
    $botEntries = file($botFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $userIp = $_SERVER['REMOTE_ADDR'] ?? '';
    foreach ($botEntries as $entry) {
        $entry = trim($entry);
        if (strpos($entry, '/') !== false) {
            if (ip_in_range($userIp, $entry)) {
                // log_event('BOT');
                http_response_code(404);
                header('Location: ' . $config['redirect_bots']);
                exit;
            }
        } else {
            if ($userIp === $entry) {
                // log_event('BOT');
                http_response_code(404);
                header('Location: ' . $config['redirect_bots']);
                exit;
            }
        }
    }
}

function ip_in_range($ip, $range) {
    list($subnet, $mask) = explode('/', $range);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = ~((1 << (32 - $mask)) - 1);
    return ($ip & $mask) === ($subnet & $mask);
}
