<?php

class EntityClient
{
    private string $domain = 'https://entitygate.com';
    private string $entity_api_key;

    public function __construct(string $entity_api_key)
    {
        $this->entity_api_key = $entity_api_key;
    }

    private function getClientIp(): string
    {
        return $_SERVER['REMOTE_ADDR'];
    }

    private function getUserAgent(): string
    {
        return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }

    private function httpGet(string $url, bool $returnStatusOnly = false): string|int
    {
        $headers = [
            'x-entity-api-key: ' . $this->entity_api_key,
            'x-visitor-ip-asli: ' . $this->getClientIp(),
            'x-visitor-user-agent: ' . $this->getUserAgent(),
            'x-visitor-accept: ' . ($_SERVER['HTTP_ACCEPT'] ?? ''),
            'x-visitor-accept-language: ' . ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''),
            'x-visitor-accept-encoding: ' . ($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''),
            'x-visitor-connection: ' . ($_SERVER['HTTP_CONNECTION'] ?? ''),
            'x-visitor-referer: ' . ($_SERVER['HTTP_REFERER'] ?? ''),
            'x-visitor-sec-fetch-site: ' . ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''),
            'x-visitor-sec-ch-ua: ' . ($_SERVER['HTTP_SEC_CH_UA'] ?? ''),
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, !$returnStatusOnly);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);

        if ($returnStatusOnly) {
            $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return $statusCode;
        }

        curl_close($ch);
        return $response;
    }

    public function fetch(string $key): array
    {
        $url = rtrim($this->domain, '/') . '/api/whoami/v1/' . urlencode($key);
        $response = $this->httpGet($url);

        $headerSize = strpos($response, "\r\n\r\n") + 4;
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        preg_match('/HTTP\/[\d\.]+\s+(\d+)/', $headers, $statusMatch);
        $status = isset($statusMatch[1]) ? (int)$statusMatch[1] : 500;

        preg_match('/Location:\s*(.+)/i', $headers, $locationMatch);
        $location = isset($locationMatch[1]) ? trim($locationMatch[1]) : null;

        return [
            'status' => $status,
            'headers' => $headers,
            'location' => $location,
            'body' => $body
        ];
    }
}
