<?php
$entity_api_key = 'PASTE_YOUR_API_KEY_HERE'; // REQUIRED, PASTE YOUR API KEY HERE
?>
